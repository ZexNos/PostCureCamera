    # Post‑Cure Camera — Overview & Master Index

    Этот файл заменяет разрозненный README и указывает на все остальные документы.
    Ниже приведён актуальный README проекта в исходном виде.

    ---


# 🧠 Post‑Cure Camera Project — Master Index

> Все методические и технические документы находятся в папке [`docs/README_Files`](docs/README_Files).

Этот README связывает все ключевые файлы проекта и служит входной точкой для работы с логикой, схемами, тестами и прошивкой.

---

## 📎 Связанные документы проекта

| Раздел | Файл | Назначение |
|---|---|---|
| 1. BOM / Комплектующие | [postcure_camera_BOM_20251026_222103.md](docs/postcure_camera_BOM_20251026_222103.md) | Финальный перечень компонентов, ревизия v2.0. |
| 2. Схемы и подключения | [postcure_camera_wiring.md](docs/postcure_camera_wiring.md) | Разводка: ESP32-S3, SSR, UV, питание, датчики, вентиляторы. |
| 3. Спецификация логики | [PostCure_Camera_SPEC_MASTER_v0.2.1.md](docs/PostCure_Camera_SPEC_MASTER_v0.2.1.md) | Единый SPEC (заменяет старые control_logic / bringup docs). |
| 4. Архитектурная карта | [PostCure_Modular_Map_v1.0.md](docs/PostCure_Modular_Map_v1.0.md) | Модули и связи (Wi-Fi/MQTT UI — deprecated). |
| 5. Методики / Ноты | см. раздел ниже | BuildFlags, UI Sandbox, Freeze, Wi-Fi/MQTT, Presets и др. |

---

## 📄 Краткое описание проекта

Post-Cure Camera — камера для UV-отверждения смол и сушки филамента.  
ESP32-S3-DevKitC-1, датчики SHT31 × 2 и DS18B20, дисплей **ST7789 160×128 (landscape)**, энкодер, статус-бар; интеграция с Home Assistant (MQTT).

**Основные функции**
- UV-отверждение: 30 × 3 Вт (400 нм), SSR-коммутация.
- Сушка филамента: 45–90 °C, внутренний/выхлопной вентиляторы, **UV-LOCK** (без УФ).
- PID-контроль нагрева; пресеты CURE/DRY.
- Wi-Fi + MQTT (**HARDCODED**, без экранов настройки).
- Safety: дверь/перегрев/сбой датчиков; RGB-индикатор состояний.

---

Список замороженных файлов и правила их изменения описаны здесь:

- docs/PROTECTED_FILES.md

Изменения в этих файлах допускаются только через явную процедуру UNFREEZE
с обновлением FREEZE-тестов и документации.

---

## ⚙️ Текущее состояние

✅ Все ключевые компоненты закуплены и протестированы по BOM v2.0.  
-🟢 Начата интеграция RGB-индикатора и экрана ST7735.  
-🟠 В работе: реализация логики Bring-Up UI и дальнейшее объединение с MQTT-контроллером.  
+🟢 Stage A: заморожены драйверы экрана ST7789 128×160, EncoderDrv, Pins.h, Colors.h и верхняя статус-строка RUN VIEW (см. `docs/PROTECTED_FILES.md`).  
+🟠 Stage C: в работе фоновый Wi-Fi/MQTT (подключение к фиксированным SSID и топикам без каких-либо сетевых меню в UI).  

> Все методические файлы: [`docs/README_Files`](docs/README_Files).

---
## 📘 Документы и методики (обновлено 2025-11-09 11:14)

### 🔧 Основные конфигурационные файлы
- [BuildFlags.md](docs/README_Files/BuildFlags.md) — описание флагов сборки, DEV/DBG‑режимов и матрицы этапов (A–F).  
- [PostCure_Modular_Map_v1.0.md](docs/PostCure_Modular_Map_v1.0.md) — архитектурная карта модулей (обновлена: Wi‑Fi/MQTT UI помечены deprecated).  
- [PostCure_Camera_SPEC_MASTER_v0.2.1.md](docs/PostCure_Camera_SPEC_MASTER_v0.2.1.md) — мастер‑спецификация, заменяющая старые control_logic и test_UI.

### 🧩 UI и визуальная логика
- [UI_Lists_and_Diff_Render.md](docs/README_Files/UI_Lists_and_Diff_Render.md) — принципы отрисовки, структура ListCtx, diff‑обновление CONTENT.  
- [UI_Feature_Sandbox_Methodology.md](docs/README_Files/UI_Feature_Sandbox_Methodology.md) — песочница для изолированного тестирования экранов.  
- [postcure_camera_UI_style_guide.md](docs/postcure_camera_UI_style_guide.md) — визуальный стиль и структура экранов (TOP/BOTTOM/CONTENT).

### ☢️ Безопасность, индикация, процессы
- [RGB_Safety_UVLOCK.md](docs/README_Files/RGB_Safety_UVLOCK.md) — поведение RGB‑индикатора, SAFE_STATE, UV‑LOCK.  
- [Presets.md](sdocs/README_Files/Presets.md) — структура и стартовые профили режимов CURE/DRY.  
- [FREEZE_TESTS_PostCureCamera_v1.0.md](docs/README_Files/FREEZE_TESTS_PostCureCamera_v1.0.md) — чек‑лист заморозки модулей Display/Encoder/Pins/Colors.

### 🌐 Сеть и интеграция
- [WiFi_Access_Note.md](docs/README_Files/WiFi_Access_Note.md) — жёсткая конфигурация Wi‑Fi (SSID, PASS, hostname).  
- [MQTT_Access_Note.md](docs/README_Files/MQTT_Access_Note.md) — параметры брокера Home Assistant (MQTT).  

> **Примечание:** Wi‑Fi и MQTT теперь инициализируются жёстко из кода (см. BuildFlags.md, WIFI_HARDCODED/MQTT_HARDCODED). UI‑экраны настройки удалены из меню.

---
### 🧱 Статус модулей (Freeze)
| Модуль | Статус | Примечание |
|--------|:--------:|------------|
| DisplayST7789 | 🟢 Frozen | Инициализация, diff‑отрисовка и зоны TOP/BOTTOM/CONTENT прошли freeze‑тесты. |
| EncoderDrv | 🟢 Frozen | Стабильные события вращения/клика/долгого нажатия. |
| Wi‑Fi Subsystem | 🟢 Frozen | Жёсткая конфигурация, стабильное подключение. |
| MQTT Subsystem | 🟠 In progress | Подключение к HA, статусы в топ‑баре. |
| Safety / RGB / Presets | ⚙️ В работе | Поведение описано в RGB_Safety_UVLOCK.md и Presets.md. |

---
