#include <PostCureCore.h>

App app;
void setup(){ app.begin(); }
void loop(){  app.tick();  }