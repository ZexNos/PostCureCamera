#pragma once
#include <Arduino.h>
#include "config/BuildFlags.h"

// 1. FORWARD DECLARATIONS для классов, используемых как ССЫЛКИ/УКАЗАТЕЛИ
class DisplayST7789;
class EncoderDrv;
class TextEditOverlay;
class Client; 
class UiRouter; // 👈 ДОБАВЛЕНО: Forward Declaration

// 2. ПОЛНЫЕ INCLUDE для классов, используемых как ЧЛЕНЫ-ОБЪЕКТЫ
#if HAS_WIFI
  #include "services/wifi/WiFiManager.h"
#endif
#if HAS_MQTT
  #include "services/mqtt/MqttManager.h" 
#endif

// --- AppState ---
// Структура для хранения глобального состояния приложения
struct AppState {
  bool wifiConnected = false;
  uint32_t wifiIp = 0; // В ESP32 IP адрес хранится как uint32_t
  bool mqttConnected = false;
};

class App {
public:
  // Конструктор: принимает зависимости по ссылке
  App(DisplayST7789& display, EncoderDrv& encoder, Client& netClient, TextEditOverlay& textEdit);

  // Основные методы жизненного цикла
  void begin();
  void tick();
  
  // Геттер для состояния
  const AppState& state() const { return _state; }

private:
  // Члены-ссылки
  DisplayST7789&   _display;
  EncoderDrv&      _encoder;
  TextEditOverlay& _textEdit;

  // Члены-объекты
  AppState _state; // Состояние приложения
  
#if HAS_WIFI
  WiFiManager _wifi; // Менеджер Wi-Fi
#endif
#if HAS_MQTT
  MqttManager _mqtt; // Менеджер MQTT
#endif
  
  // 👈 ДОБАВЛЕНО: Указатель на роутер
  UiRouter* _router = nullptr; 
};