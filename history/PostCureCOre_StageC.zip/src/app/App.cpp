#include "app/App.h"
#include "config/BuildFlags.h"

#include "drivers/DisplayST7789.h"
#include "drivers/Encoder.h"
#include "ui/widgets/TextEdit.h"
#include <Client.h> 

#include "ui/UiRouter.h" // 👈 ДОБАВЛЕНО: Включаем заголовок роутера

// ===================================================================
// КОНСТРУКТОР
// ===================================================================
// Принимает Client& netClient, который будет передан в MqttManager.
App::App(DisplayST7789& display, EncoderDrv& encoder, Client& netClient, TextEditOverlay& textEdit)
  : _display(display),
    _encoder(encoder),
    _textEdit(textEdit)
#if HAS_WIFI
    , _wifi()
#endif
#if HAS_MQTT
    , _mqtt(netClient)
#endif
{
    // 👈 ДОБАВЛЕНО: Создаем экземпляр роутера
    _router = new UiRouter(); 
}


// ===================================================================
// begin()
// ===================================================================
void App::begin() {
  // 1. Инициализация драйверов
  _display.begin();
  _encoder.begin();
  
  // 2. Инициализация UI-виджетов и сервисов
  // ИСПРАВЛЕНО: Теперь begin() TextEdit принимает зависимости
  if (_router) { // _router должен быть инициализирован в конструкторе
      _router->begin(&_display, &_encoder, &_wifi, &_mqtt);
  }
  
  _textEdit.begin(&_display, &_encoder); // 👈 ИСПРАВЛЕНО: Передаем зависимости

  _display.setInverted(false); 
  
#if HAS_WIFI
  _wifi.begin();
#endif
#if HAS_MQTT
  _mqtt.begin();
#endif
  
  // 👈 АКТИВАЦИЯ UiRouter
  if (_router) {
      // Это было сделано выше. Если UiRouter::begin() вызывает draw(), он готов.
  }
}


// ===================================================================
// tick()
// ===================================================================
void App::tick() {
  // 1. Опрос ввода
  _encoder.tick();
  _textEdit.tick();

  // 2. Обновление состояния сервисов
#if HAS_WIFI
  _wifi.tick();
  _state.wifiConnected = _wifi.connected();
  _state.wifiIp = _wifi.ip();
#endif

#if HAS_MQTT
  if (_state.wifiConnected) {
    _mqtt.tick();
    _state.mqttConnected = _mqtt.connected();
  } else {
    _state.mqttConnected = false;
  }
#endif
  
  // 👈 ЛОГИКА UiRouter
  // Вызываем tick() роутера, только если TextEdit не активен (он модальный)
  if (_router && !_textEdit.isActive()) {
      _router->tick();
  }

  // 3. Обновление UI
  _display.updateTopBar(_state.wifiConnected, _state.mqttConnected, false, false); 
  if (_textEdit.isActive()) {
    _textEdit.draw();
  } else {
    // Рисует активный в данный момент экран (RunView, Options, и т.д.)
    // Вызывается в конце tick() только если нет модального окна
    if (_router) {
        _router->draw(); 
    }
  }
}