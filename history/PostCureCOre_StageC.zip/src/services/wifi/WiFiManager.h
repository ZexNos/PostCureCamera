// services/wifi/WiFiManager.h

#pragma once

#include <Arduino.h>
// Добавляем общий заголовок для работы с Wi-Fi
#include <WiFi.h> 

class WiFiManager {
public:
    // Конструктор
    WiFiManager(); 

    // Основные методы жизненного цикла
    void begin();
    void tick();
    bool connected() const;
    
    // Получение текущего IP адреса (используется в App.cpp)
    uint32_t ip() const; 

    // -------------------------------------------------------------------
    // Методы для работы с сохраненными настройками (Требования UI)
    // -------------------------------------------------------------------

    // Геттеры (используются в WiFiSetup::begin)
    String getStoredSsid() const;
    String getStoredPass() const;
    
    // Сеттеры (используются в WiFiSetup::tick)
    void setStoredSsid(const String& ssid);
    void setStoredPass(const String& pass);
    
    // Сохранение конфигурации (используется в WiFiSetup::tick)
    void saveConfig();

private:
    // Локальное хранилище настроек (должно загружаться/сохраняться через EEPROM/Preferences)
    String _ssid = "Your_WiFi_SSID";
    String _pass = "Your_WiFi_Password";
    
    bool _isConnected = false;
    uint32_t _currentIp = 0; // Текущий IP-адрес
    
    // Приватные методы для логики
    void _connect();
};