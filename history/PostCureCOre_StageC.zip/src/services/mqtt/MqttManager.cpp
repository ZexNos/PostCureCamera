// services/mqtt/MqttManager.cpp

#include "services/mqtt/MqttManager.h"
#include <WiFi.h>  // для WiFi.status()
#include <Arduino.h>

// Значения по умолчанию для NVS
static const char* NVS_BROKER    = "broker";
static const char* NVS_PORT      = "port";
static const char* NVS_CLIENT_ID = "clientId";
static const char* NVS_ROOT      = "root";
static const char* NVS_USER      = "user";
static const char* NVS_PASS      = "pass";

// ===== ctor =====
MqttManager::MqttManager(Client& net)
: _net(net), _mqtt(_net) {
}

// ===== public =====
void MqttManager::begin() {
  _nvs.begin("mqtt", /*ro=*/false);
  loadFromNvs();

  // Применяем настройки
  _mqtt.setServer(_cfg.broker.c_str(), _cfg.port);
  _mqtt.setCallback([this](char* t, uint8_t* p, unsigned int l){
    this->onMqttMessage(t, p, l);
  });
}

void MqttManager::tick() {
  // MQTT не может работать без активного Wi-Fi
  if (WiFi.status() != WL_CONNECTED) return;

  ensureConnected();
  _mqtt.loop();
}

bool MqttManager::connected() {
  // NOTE: PubSubClient::connected() не является const, но мы оставляем
  // метод без const, чтобы избежать лишней проверки.
  return _mqtt.connected();
}

MqttManager::Config MqttManager::cfg() const {
  return _cfg;
}

void MqttManager::setConfig(const Config& c, bool saveNvs) {
  _cfg = c;
  // Обновляем сервер, если он изменился
  _mqtt.setServer(_cfg.broker.c_str(), _cfg.port);
  
  if (saveNvs) saveToNvs();
}

// ===== NVS IO =====
void MqttManager::loadFromNvs() {
  _cfg.broker    = _nvs.getString (NVS_BROKER,   _cfg.broker);
  _cfg.port      = _nvs.getUShort (NVS_PORT,     _cfg.port);
  _cfg.clientId  = _nvs.getString (NVS_CLIENT_ID, _cfg.clientId);
  _cfg.topicRoot = _nvs.getString (NVS_ROOT,     _cfg.topicRoot);
  _cfg.user      = _nvs.getString (NVS_USER,     _cfg.user);
  _cfg.pass      = _nvs.getString (NVS_PASS,     _cfg.pass);
}

void MqttManager::saveToNvs() {
  // Preferences::put* не const, поэтому метод не может быть const
  _nvs.putString(NVS_BROKER,   _cfg.broker);
  _nvs.putUShort(NVS_PORT,     _cfg.port);
  _nvs.putString(NVS_CLIENT_ID, _cfg.clientId);
  _nvs.putString(NVS_ROOT,     _cfg.topicRoot);
  _nvs.putString(NVS_USER,     _cfg.user);
  _nvs.putString(NVS_PASS,     _cfg.pass);
}

// ===== MQTT API =====
void MqttManager::setCallback(MessageCb cb) {
  _cb = cb;
}

bool MqttManager::subscribe(const String& topic) {
  if (!_mqtt.connected()) return false;
  return _mqtt.subscribe(topic.c_str());
}

bool MqttManager::publish(const String& topic, const String& payload, bool retained) {
  if (!_mqtt.connected()) return false;
  return _mqtt.publish(topic.c_str(), payload.c_str(), retained);
}

String MqttManager::topicCommandRoot() const {
  return _cfg.topicRoot + F("/command");
}

String MqttManager::topicEventRoot() const {
  return _cfg.topicRoot + F("/event");
}

// ===== private =====
void MqttManager::ensureConnected() {
  if (_mqtt.connected()) return;

  // КРИТИЧЕСКОЕ ИСПРАВЛЕНИЕ: Неблокирующий реконнект
  // Если время с последней попытки меньше RECONNECT_DELAY_MS, выходим.
  if (millis() - _lastReconnectTry < RECONNECT_DELAY_MS) {
    return;
  }

  _lastReconnectTry = millis(); // Сбрасываем таймер перед попыткой

  Serial.print(F("Attempting MQTT connection..."));
  
  bool result = false;
  // Используем логин/пароль, если они заданы
  if (_cfg.user.length() || _cfg.pass.length()) {
    result = _mqtt.connect(_cfg.clientId.c_str(), _cfg.user.c_str(), _cfg.pass.c_str());
  } else {
    result = _mqtt.connect(_cfg.clientId.c_str());
  }
  
  if (result) {
    Serial.println(F(" connected"));
    // Если подключение удалось, подписываемся на команды
    subscribe(topicCommandRoot() + F("/#"));
  } else {
    Serial.print(F(" failed, rc="));
    Serial.println(_mqtt.state());
  }
}

void MqttManager::onMqttMessage(char* topic, uint8_t* payload, unsigned int len) {
  if (!_cb) return;

  // Payload: конвертируем в String (нулевой байт гарантированно добавится)
  payload[len] = '\0';
  String topicStr(topic);
  String payloadStr((char*)payload);
  
  // Вызываем внешний колбэк
  _cb(topicStr, payloadStr);
}