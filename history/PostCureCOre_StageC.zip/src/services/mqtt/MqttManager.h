// services/mqtt/MqttManager.h

#pragma once

#include <Arduino.h>
// Forward declaration для сетевого клиента (например, WiFiClient, который наследует Client)
// Это необходимо, так как MqttManager принимает его в конструкторе.
class Client; 

class MqttManager {
public:
    // Конструктор: принимает ссылку на Client для работы с сетью (например, WiFiClient)
    MqttManager(Client& netClient); 

    // Основные методы жизненного цикла
    void begin();
    void tick();
    bool connected() const;

    // -------------------------------------------------------------------
    // Методы для работы с сохраненными настройками (Требования UI)
    // -------------------------------------------------------------------

    // Геттеры (используются в MqttSettingsScreen::begin)
    String getStoredBroker() const;
    uint16_t getStoredPort() const;
    String getStoredClientId() const;
    String getStoredRootTopic() const;
    String getStoredUser() const;
    String getStoredPass() const;
    
    // Сеттеры (используются в MqttSettingsScreen::tick)
    void setStoredBroker(const String& broker);
    void setStoredPort(uint16_t port);
    void setStoredClientId(const String& client);
    void setStoredRootTopic(const String& root);
    void setStoredUser(const String& user);
    void setStoredPass(const String& pass);
    
    // Сохранение конфигурации (используется в MqttSettingsScreen::tick)
    void saveConfig(); 

private:
    // Член-ссылка на сетевой клиент
    Client& _netClient;

    // Локальное хранилище настроек (должно загружаться/сохраняться через EEPROM/Preferences)
    String _broker = "test.mosquitto.org";
    uint16_t _port = 1883;
    String _clientId = "ESP32_Device";
    String _rootTopic = "home/device";
    String _user = "";
    String _pass = "";

    bool _isConnected = false;
    
    // Приватные методы для логики
    void _connect();
    // Здесь должен быть член класса PubSubClient (для полной реализации)
    // PubSubClient _client; 
};