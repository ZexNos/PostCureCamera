#pragma once
#include <Arduino.h>
#define RGB565(r,g,b) ( ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | ((b) >> 3) )

static const uint16_t COL_BG        = RGB565(10, 12, 14);
static const uint16_t COL_BAR       = RGB565(18, 20, 24);
static const uint16_t COL_TEXT      = RGB565(220, 220, 220);
static const uint16_t COL_TEXT_DIM  = RGB565(160, 160, 160);
static const uint16_t COL_ACCENT    = RGB565(255, 160, 64);
static const uint16_t COL_WARN      = RGB565(255, 64, 64);
static const uint16_t COL_LINE      = RGB565(60, 64, 70);
static const uint16_t COL_TILE      = RGB565(26, 28, 32);

static const uint8_t  UI_ROTATION = 1;
static const uint16_t UI_W        = 160;
static const uint16_t UI_H        = 128;
static const uint8_t  UI_BAR_H    = 16;
