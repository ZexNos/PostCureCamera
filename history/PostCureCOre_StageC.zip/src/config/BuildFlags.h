#pragma once
// Build flags for staged compilation
#ifndef HAS_WIFI
#define HAS_WIFI 1
#endif

#ifndef HAS_MQTT
#define HAS_MQTT 1
#endif
