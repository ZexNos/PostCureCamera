#pragma once

// Display ST7789
#define PIN_TFT_CS     5
#define PIN_TFT_DC     4
#define PIN_TFT_RST    6
#define PIN_TFT_SCLK   12
#define PIN_TFT_MOSI   13

// Encoder (EncButton)
#define PIN_ENC_A      7
#define PIN_ENC_B      8
#define PIN_ENC_BTN    9

// RGB LED
#define PIN_RGB        48
