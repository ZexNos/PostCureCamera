#pragma once
#include <Arduino.h>
#include <functional>

// 👈 Forward Declarations для зависимостей
class DisplayST7789;
class EncoderDrv;

struct TextEditParams {
  const char* title = "Input";
  String      initial;
  uint8_t     maxLen = 64;
  bool        mask   = false;
};

class TextEditOverlay {
public:
  using CloseCb = std::function<void(bool ok, const String& val)>;

  // 👈 ИСПРАВЛЕНО: begin() теперь принимает зависимости
  void begin(DisplayST7789* d, EncoderDrv* e); 

  void open(const TextEditParams& p, CloseCb cb);   // основной API
  void open(const char* title, String* target, uint8_t maxLen, bool password);

  void tick();
  void draw();

  bool isActive() const { return _active; }

private:
  void close(bool ok);

  bool    _active   = false;
  String  _buf;
  uint8_t _maxLen   = 64;
  bool    _mask     = false;
  String  _titleStr;
  CloseCb _cb;
  
  // 👈 ДОБАВЛЕНО: Недостающие члены класса
  DisplayST7789* _disp = nullptr; 
  EncoderDrv* _enc  = nullptr;
  
  // очень простая навигация: 0=field,1=DEL,2=OK,3=Back
  uint8_t _sel = 0;
};

extern TextEditOverlay TextEdit;