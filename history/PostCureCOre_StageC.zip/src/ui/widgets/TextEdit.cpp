// src/ui/widgets/TextEdit.cpp
#include "TextEdit.h"
#include "drivers/DisplayST7789.h"
#include "drivers/Encoder.h"
#include "config/Colors.h" // <-- Все UI константы

// --- УДАЛЕНО: ВСЕ ЗАПАСНЫЕ #ifndef КОНСТАНТЫ ---

TextEditOverlay TextEdit;

// ИСПРАВЛЕНО: Инициализация зависимостей
void TextEditOverlay::begin(DisplayST7789* d, EncoderDrv* e){
  _disp = d; 
  _enc = e;
}

void TextEditOverlay::open(const TextEditParams& p, CloseCb cb){
  _active = true;
  _titleStr = p.title ? p.title : "Input";
  _buf = p.initial;
  _maxLen = p.maxLen ? p.maxLen : 64;
  _mask = p.mask;
  _cb = cb;
  _sel = 0;
}

void TextEditOverlay::open(const char* title, String* target, uint8_t maxLen, bool password){
  TextEditParams p;
  p.title = title ? title : "Input";
  p.initial = target ? *target : String();
  p.maxLen = maxLen;
  p.mask = password;
  // Оборачиваем колбэк: записать результат обратно в *target
  open(p, [target](bool ok, const String& val){
    if (ok && target) *target = val;
  });
}

void TextEditOverlay::close(bool ok){
  CloseCb cb = _cb;
  String val = _buf;
  _active = false;
  _cb = nullptr;
  if (_disp) _disp->clearBody(); // 👈 ИСПРАВЛЕНО: Используем _disp
  if (cb) cb(ok, val);
}

void TextEditOverlay::tick(){
  if (!_active) return;
  
  // ... ваш код обработки ввода ...
  
  if (!_enc) return;
  if (_enc->right()){
    if (_sel < 2) _sel++;
  }
  if (_enc->left()){
    if (_sel > 0) _sel--;
  }

  if (_enc->click()){
    if (_sel == 2){ // OK
      close(true);
    } else if (_sel == 1){ // BACK
      close(false);
    }
    // _sel == 0 (Field) - здесь должна быть логика ввода текста
    // В текущей минимальной версии это не реализовано
  }

}

void TextEditOverlay::draw(){
  if (!_active || !_disp) return;

  auto& t = _disp->gfx();
  // Координаты окна (центрируем)
  const int w = 150, h = 90;
  const int x = (UI_W - w) / 2;
  const int y = (UI_H - h) / 2;

  // 1. Рисуем тело окна
  t.fillRoundRect(x, y, w, h, 4, COL_TILE); // Фон окна
  t.drawRoundRect(x, y, w, h, 4, COL_ACCENT); // Рамка
  
  // 2. Заголовок
  t.setTextSize(1);
  t.setTextColor(COL_TEXT, COL_TILE);
  t.setCursor(x + 4, y + 4);
  t.print(_titleStr);
  
  // 3. Поле ввода (просто имитация)
  const int fieldY = y + 20;
  const int fieldH = 16;
  uint16_t fieldBG = _sel == 0 ? COL_LINE : COL_BG;
  t.fillRect(x + 4, fieldY, w - 8, fieldH, fieldBG);
  t.drawRect(x + 4, fieldY, w - 8, fieldH, _sel == 0 ? COL_ACCENT : COL_LINE);
  
  t.setTextColor(COL_TEXT, fieldBG);
  t.setCursor(x + 6, fieldY + 4);
  
  if (_mask) {
    String masked;
    for (size_t i = 0; i < _buf.length(); i++) masked += '*';
    t.print(masked);
  } else {
    t.print(_buf);
  }
  
  // 4. Кнопки (BACK и OK)
  const int btnW = (w - 12) / 2;
  const int btnY = y + h - 22;

  // Кнопка BACK
  bool selBack = (_sel == 1); // 1 = BACK
  t.fillRoundRect(x + 4, btnY, btnW, 16, 3, selBack ? COL_ACCENT : COL_TILE);
  t.drawRoundRect(x + 4, btnY, btnW, 16, 3, selBack ? COL_ACCENT : COL_LINE);
  t.setTextColor(selBack ? COL_BG : COL_TEXT, selBack ? COL_ACCENT : COL_TILE);
  t.setCursor(x + 4 + btnW/2 - 10, btnY + 4); 
  t.print("Back");

  // Кнопка OK
  bool selOK = (_sel == 2); // 2 = OK
  t.fillRoundRect(x + 8 + btnW, btnY, btnW, 16, 3, selOK ? COL_ACCENT : COL_TILE);
  t.drawRoundRect(x + 8 + btnW, btnY, btnW, 16, 3, selOK ? COL_ACCENT : COL_LINE);
  t.setTextColor(selOK ? COL_BG : COL_TEXT, selOK ? COL_ACCENT : COL_TILE);
  t.setCursor(x + 8 + btnW + btnW/2 - 6, btnY + 4); 
  t.print("OK");
}