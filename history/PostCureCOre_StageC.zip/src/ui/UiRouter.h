#pragma once
#include "widgets/TextEdit.h"
#include <Arduino.h>

// forward declarations (без тяжёлых include в .h)
class DisplayST7789;
class EncoderDrv;
class WiFiManager;
class MqttManager;

class RunView;
class OptionsMenu;
class WiFiSetup;
class MqttSettingsScreen;
class TextEditOverlay;

class UiRouter {
public:
  enum Screen : uint8_t { S_HOME=0, S_OPTIONS, S_WIFI, S_MQTT };

  void begin(DisplayST7789* d, EncoderDrv* e, WiFiManager* wifi, MqttManager* mqtt);
  void tick();

  void open(Screen s);
  Screen current() const { return _cur; }

private:
  // deps
  DisplayST7789* _d = nullptr;
  EncoderDrv* _e = nullptr;
  WiFiManager* _wifi = nullptr;
  MqttManager* _mqtt = nullptr;

  // общий редактор текста
  TextEditOverlay* _editor = nullptr;

  // экраны
  RunView* _home       = nullptr;
  OptionsMenu* _opts       = nullptr;
  WiFiSetup* _wifiScreen = nullptr;
  MqttSettingsScreen* _mqttScreen = nullptr;

  // состояние
  Screen _cur = S_HOME;

  // 👈 КОРРЕКТНЫЕ ДЕКЛАРАЦИИ МЕТОДОВ
  void enterHome();
  void enterOptions();
  void enterCure();
  void enterDry();
  void enterWiFiSetup();
  void enterMqttSetup();
};