#include "ui/screens/MqttSettings.h"
#include "ui/widgets/TextEdit.h"
#include "drivers/DisplayST7789.h"
#include "drivers/Encoder.h"
#include "config/Colors.h"
#include "services/mqtt/MqttManager.h"

#ifndef UI_W
  #define UI_W 160
#endif
#ifndef UI_BAR_H
  #define UI_BAR_H 16
#endif

// ====================================================================
// ИНИЦИАЛИЗАЦИЯ
// ====================================================================

void MqttSettingsScreen::begin(DisplayST7789* d, EncoderDrv* e, MqttManager* m, TextEditOverlay* ed){
  _disp = d; _enc = e; _mqtt = m; _edit = ed;
  
  // Загружаем текущие сохраненные значения из MqttManager для редактирования
  _broker = m->getStoredBroker();
  _port   = m->getStoredPort();
  _client = m->getStoredClientId();
  _root   = m->getStoredRootTopic();
  _user   = m->getStoredUser();
  _pass   = m->getStoredPass();
  
  _sel = F_BROKER;
  _done = false;
  drawStatic();
}

// ====================================================================
// Отрисовка
// ====================================================================

void MqttSettingsScreen::drawStatic(){
  if (!_disp) return;
  _disp->clearBody();

  // Заголовок в теле (под системной строкой)
  _disp->gfx().setTextSize(1);
  _disp->gfx().setTextColor(COL_TEXT, COL_BG);
  _disp->gfx().setCursor(6, UI_BAR_H + 2);
  _disp->gfx().print("MQTT Settings");

  drawList();

  // Хинт внизу тела
  _disp->gfx().setTextColor(COL_TEXT_DIM, COL_BG);
  // Y-координата = UI_BAR_H + 2 + 14 (заголовок) + 6*16 (6 строк по 16) + 6 (отступ)
  _disp->gfx().setCursor(6, UI_BAR_H + 2 + 14 + 8*16 + 6); // 8 строк, т.к. F_COUNT=9
  _disp->gfx().print("< > Select   v OK");
}

void MqttSettingsScreen::drawList(){
  if (!_disp) return;
  auto& t = _disp->gfx();
  t.fillRect(0, UI_BAR_H + 2 + 14, UI_W, 8*16, COL_BG); // Очищаем только список

  for (uint8_t i=0; i < F_COUNT; ++i){
    drawRow(i, i == _sel);
  }
}

void MqttSettingsScreen::drawRow(uint8_t idx, bool selected){
  if (!_disp) return;
  auto& t = _disp->gfx();
  const int y = UI_BAR_H + 2 + 14 + idx * 16;
  const int rowH = 16;
  const int padx = 6;
  
  uint16_t bg = selected ? COL_TILE : COL_BG;
  uint16_t ol = selected ? COL_ACCENT : COL_LINE;
  
  const char* key;
  String val;
  bool is_button = false;
  bool is_masked = false;

  switch (idx){
    case F_BROKER: key = "Broker:"; val = _broker; break;
    case F_PORT:   key = "Port:";   val = String(_port); break;
    case F_CLIENT: key = "Client:"; val = _client; break;
    case F_ROOT:   key = "Root:";   val = _root; break;
    case F_USER:   key = "User:";   val = _user; break;
    case F_PASS:   key = "Pass:";   val = _pass; is_masked = true; break;
    case F_APPLY:  key = "Apply";   is_button = true; break;
    case F_BACK:   key = "Back";    is_button = true; break;
    default: return;
  }
  
  if (is_button){
    uint16_t btn_bg = selected ? COL_ACCENT : COL_TILE;
    uint16_t btn_fg = selected ? COL_BG : COL_TEXT;
    t.fillRoundRect(padx, y, UI_W-2*padx, rowH-2, 3, btn_bg);
    t.drawRoundRect(padx, y, UI_W-2*padx, rowH-2, 3, ol);
    t.setTextSize(1);
    t.setTextColor(btn_fg, btn_bg);
    t.setCursor(UI_W/2 - 20, y + 4); 
    t.print(key);
  } else {
    // Фон и рамка
    t.fillRoundRect(padx, y, UI_W-2*padx, rowH-2, 3, bg);
    t.drawRoundRect(padx, y, UI_W-2*padx, rowH-2, 3, ol);
    
    // Ключ
    t.setTextSize(1);
    t.setTextColor(COL_TEXT_DIM, bg);
    t.setCursor(padx + 4, y + 4);
    t.print(key);

    // Значение
    t.setTextColor(COL_TEXT, bg);
    t.setCursor(60, y + 4);
    
    // Маскирование
    if (is_masked) {
      String masked_v;
      for (size_t i = 0; i < val.length(); i++) masked_v += '*';
      t.print(masked_v);
    } else {
      t.print(val);
    }
  }
}

// ====================================================================
// ОБРАБОТКА ВВОДА
// ====================================================================

void MqttSettingsScreen::tick(){
  // Если активен редактор, мы ждем его закрытия
  if (_edit && _edit->isActive()) return;

  bool redraw = false;
  
  // Навигация (кольцевая)
  if (_enc->right()){ 
    _sel = (_sel + 1) % F_COUNT; 
    redraw = true; 
  }
  if (_enc->left()){  
    _sel = (_sel + F_COUNT - 1) % F_COUNT; 
    redraw = true; 
  }
  
  if (redraw){ drawList(); return; }

  if (_enc->click()){
    
    // Хелпер для открытия редактора текста
    auto openTextEditor = [this](const char* title, String& target, uint8_t maxLen, bool password){
      if (_edit){
        TextEditParams p; 
        p.title=title; 
        p.initial=target; 
        p.maxLen=maxLen; 
        p.mask=password; 
        _edit->open(p, [this, &target](bool ok, const String& val){ 
          if (ok) target=val; 
          this->drawList(); // Перерисовать список после закрытия
        }); 
      }
    };
    
    // Хелпер для открытия редактора числа (Порт)
    auto openNumEditor = [this](uint16_t& target, const char* title, uint8_t maxLen){
      if (_edit){
        TextEditParams p; 
        p.title=title; 
        p.initial=String(target); 
        p.maxLen=maxLen; 
        p.mask=false; 
        _edit->open(p, [this, &target](bool ok, const String& val){ 
          if (ok){ 
            long v=val.toInt(); 
            // Ограничение порта
            if (v<0) v=0; 
            if (v>65535) v=65535; 
            target=(uint16_t)v; 
          } 
          this->drawList();
        }); 
      }
    };
    
    // Выбор действия по полю
    switch (_sel){
      case F_BROKER: openTextEditor("Broker", _broker, 64, false); break;
      case F_PORT:   openNumEditor(_port, "Port", 5); break;
      case F_CLIENT: openTextEditor("Client", _client, 32, false); break;
      case F_ROOT:   openTextEditor("Root Topic", _root, 32, false); break;
      case F_USER:   openTextEditor("User", _user, 32, false); break;
      case F_PASS:   openTextEditor("Password", _pass, 32, true); break;
        
      case F_APPLY: 
        // Сохранить новые настройки и завершить экран
        _mqtt->setStoredBroker(_broker);
        _mqtt->setStoredPort(_port);
        _mqtt->setStoredClientId(_client);
        _mqtt->setStoredRootTopic(_root);
        _mqtt->setStoredUser(_user);
        _mqtt->setStoredPass(_pass);
        _mqtt->saveConfig();
        _done = true;
        break;
        
      case F_BACK:
        _done = true;
        break;
    }
  }
}

// Конец MqttSettings.cpp