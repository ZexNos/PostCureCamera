#pragma once
#include <Arduino.h>
#include "ui/widgets/TextEdit.h"

class DisplayST7789;
class EncoderDrv;
class MqttManager;

class MqttSettingsScreen {
public:
  enum Field : uint8_t { F_BROKER=0, F_PORT, F_CLIENT, F_ROOT, F_USER, F_PASS, F_APPLY, F_BACK, F_COUNT };
  enum Mode  : uint8_t { MODE_NAV=0, MODE_EDIT_NUM };

  void begin(DisplayST7789* d, EncoderDrv* e, MqttManager* m, TextEditOverlay* editor);
  void drawStatic();
  void tick();
  bool isDone() const { return _done; }

private:
  void drawList();
  void drawRow(uint8_t idx, bool selected);
  void redrawRow(uint8_t idx, bool selected);
  void drawFooter(const char* msg);

  void enterNumEdit();
  void exitNumEdit();
  void stepNumber(int dir);

  static bool isTextField(uint8_t idx);
  static bool isNumField (uint8_t idx);

  DisplayST7789* _disp = nullptr;
  EncoderDrv*    _enc  = nullptr;
  MqttManager*   _mqtt = nullptr;
  TextEditOverlay* _edit = nullptr;

  // cache
  String   _broker;
  uint16_t _port   = 1883;
  String   _client;
  String   _root;
  String   _user;
  String   _pass;

  // ui
  uint8_t _sel   = 0;
  Mode    _mode  = MODE_NAV;
  bool    _done  = false;
};
