#include "ui/screens/RunView.h"
#include "drivers/DisplayST7789.h"
#include "drivers/Encoder.h"
#include "config/Colors.h" // <-- Все константы отсюда

void RunView::begin(DisplayST7789* d, EncoderDrv* e){
  _disp = d; _enc = e; _sel = 0;
}

static void drawTileFrame(Adafruit_ST7789& g, int x, int y, int w, int h, bool sel){
  g.fillRoundRect(x, y, w, h, 6, COL_TILE);
  g.drawRoundRect(x, y, w, h, 6, sel ? COL_ACCENT : COL_LINE);
}

void RunView::draw(){
  _disp->clearBody();
  drawHeader();
  drawTiles();
}

void RunView::drawHeader(){
  auto& t = _disp->gfx();
  t.setTextSize(1);
  t.setTextColor(COL_TEXT, COL_BG);
  t.setCursor(6, UI_BAR_H + 6);
  t.print("STATUS: Ready");
}

void RunView::drawTiles(){
  const int w = 44, h = 44;
  const int spacing = 8;
  const int x0 = 10;
  const int y0 = UI_BAR_H + 28;
  
  for (int i=0;i<3;++i){
    int x = x0 + i*(w+spacing);
    bool sel = (_sel == i);
    
    drawTileFrame(_disp->gfx(), x, y0, w, h, sel);
    
    _disp->gfx().setTextSize(2);
    _disp->gfx().setCursor(x + 14, y0 + 12);
    _disp->gfx().setTextColor(sel ? COL_ACCENT : COL_TEXT, COL_TILE);
    
    switch(i){
      case 0: _disp->gfx().print("C"); break; // Cure
      case 1: _disp->gfx().print("D"); break; // Dry
      case 2: _disp->gfx().print("S"); break; // Setup
    }
  }
}

void RunView::tick(){
  if (!_enc) return;
  bool redraw = false;

  if (_enc->right()){ if (_sel < 2) _sel++; redraw=true; }
  if (_enc->left()){  if (_sel > 0) _sel--; redraw=true; }

  if (_enc->click()){
    if (_sel == 0)      _pending = ACT_ENTER_CURE;
    else if (_sel == 1) _pending = ACT_ENTER_DRY;
    else if (_sel == 2) _pending = ACT_ENTER_SETUP;
  }
  
  if (redraw) drawTiles();
}

RunView::Action RunView::takeAction(){
  Action a = _pending;
  _pending = ACT_NONE;
  return a;
}