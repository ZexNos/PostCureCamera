#pragma once
#include <Arduino.h>

class DisplayST7789;
class EncoderDrv;

class RunView {
public:
  enum Action : uint8_t { ACT_NONE=0, ACT_ENTER_CURE, ACT_ENTER_DRY, ACT_ENTER_SETUP };

  void begin(DisplayST7789* d, EncoderDrv* e);
  void draw();     // полный редроу экрана
  void tick();     // события (enc.tick() дергается в App)
  Action takeAction();

private:
  // 👈 ИСПРАВЛЕНО: Добавлена декларация drawFooter()
  void drawTiles();
  void drawTile(uint8_t idx, bool selected);
  void drawHeader();
  void drawFooter(); 

  DisplayST7789* _disp = nullptr;
  EncoderDrv* _enc  = nullptr;

  uint8_t _sel = 0;         // 0=CURE, 1=DRY, 2=SETUP
  Action  _pending = ACT_NONE;
};