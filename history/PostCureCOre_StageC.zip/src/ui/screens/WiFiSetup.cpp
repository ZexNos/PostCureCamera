#include "ui/screens/WiFiSetup.h"
#include "ui/widgets/TextEdit.h"
#include "drivers/DisplayST7789.h"
#include "drivers/Encoder.h"
#include "config/Colors.h"
#include "services/wifi/WiFiManager.h"

#ifndef UI_W
  #define UI_W 160
#endif
#ifndef UI_BAR_H
  #define UI_BAR_H 16
#endif

// ====================================================================
// ИНИЦИАЛИЗАЦИЯ
// ====================================================================

void WiFiSetup::begin(DisplayST7789* d, EncoderDrv* e, WiFiManager* w){
  _disp = d; _enc = e; _wifi = w;
  
  // Загружаем текущие сохраненные значения из WiFiManager для редактирования
  _ssid = w->getStoredSsid();
  _pass = w->getStoredPass();

  _sel  = 0;         // 0=SSID, 1=PASS, 2=Apply, 3=Back
  _done = false;
  draw();
}

void WiFiSetup::setEditor(TextEditOverlay* ed){ _edit = ed; }

// ====================================================================
// Отрисовка
// ====================================================================

void WiFiSetup::draw(){
  if (!_disp) return;

  _disp->clearBody();

  // заголовок
  _disp->gfx().setTextColor(COL_TEXT, COL_BG);
  _disp->gfx().setCursor(6, UI_BAR_H + 2);
  _disp->gfx().setTextSize(1);
  _disp->gfx().print("Wi-Fi Setup");

  // список полей
  uint8_t y = UI_BAR_H + 2 + 18; // Сдвиг для второй строки
  const int rowH = 18;
  auto& t = _disp->gfx();

  // Локальная функция для отрисовки строки
  auto line = [&](const char* k, const String& v, bool sel, bool masked=false){
    uint16_t bg = sel ? COL_TILE : COL_BG;
    uint16_t ol = sel ? COL_ACCENT : COL_LINE;

    // Фон и рамка
    t.fillRoundRect(6, y-2, UI_W-12, rowH, 3, bg);
    t.drawRoundRect(6, y-2, UI_W-12, rowH, 3, ol);

    // Ключ
    t.setTextSize(1);
    t.setTextColor(COL_TEXT_DIM, bg);
    t.setCursor(10, y+2);
    t.print(k);

    // Значение
    t.setTextColor(COL_TEXT, bg);
    t.setCursor(60, y+2);
    
    // Маскирование пароля
    if (masked) {
      String masked_v;
      for (size_t i = 0; i < v.length(); i++) masked_v += '*';
      t.print(masked_v);
    } else {
      t.print(v);
    }
    y += rowH;
  };

  // Отрисовка полей
  line("SSID:", _ssid, _sel == 0, false);
  line("PASS:", _pass, _sel == 1, true);

  // Кнопки Apply / Back
  y += 6;
  const int bw = (UI_W - 18) / 2;
  bool selApply = (_sel == 2);
  bool selBack  = (_sel == 3);

  // Apply
  _disp->gfx().fillRoundRect(6, y, bw, 16, 3, selApply ? COL_ACCENT : COL_TILE);
  _disp->gfx().drawRoundRect(6, y, bw, 16, 3, selApply ? COL_ACCENT : COL_LINE);
  
  // Back
  _disp->gfx().fillRoundRect(12 + bw, y, bw, 16, 3, selBack  ? COL_ACCENT : COL_TILE);
  _disp->gfx().drawRoundRect(12 + bw, y, bw, 16, 3, selBack  ? COL_ACCENT : COL_LINE);
  
  _disp->gfx().setTextColor(selApply ? COL_BG : COL_TEXT, selApply ? COL_ACCENT : COL_TILE);
  _disp->gfx().setCursor(6 + bw/2 - 10,  y+4);  _disp->gfx().print("Apply");
  
  _disp->gfx().setTextColor(selBack ? COL_BG : COL_TEXT,  selBack  ? COL_ACCENT : COL_TILE);
  _disp->gfx().setCursor(12 + bw + bw/2 - 8, y+4);  _disp->gfx().print("Back");

  // хинт
  _disp->gfx().setTextColor(COL_TEXT_DIM, COL_BG);
  _disp->gfx().setCursor(6, UI_BAR_H + 2 + 14 + 2*18 + 6 + 18);
  _disp->gfx().print("< > Select   v OK");
}

// ====================================================================
// ОБРАБОТКА ВВОДА
// ====================================================================

void WiFiSetup::tick(){
  // Если активен редактор, мы ждем его закрытия
  if (_edit && _edit->isActive()) return;

  bool redraw=false;
  if (_enc->right()){ if (_sel < 3) _sel++; redraw=true; }
  if (_enc->left()){  if (_sel > 0) _sel--; redraw=true; }
  if (redraw){ draw(); return; }

  if (_enc->click()){
    if (_sel == 0) { // SSID
      if (_edit){ 
        TextEditParams p; 
        p.title="SSID"; 
        p.initial=_ssid; 
        p.maxLen=32; 
        p.mask=false; 
        _edit->open(p, [this](bool ok, const String& val){ 
          if (ok) _ssid=val; 
          this->draw(); // Перерисовать после закрытия редактора
        }); 
      } 
    }
    else if (_sel == 1) { // PASSWORD
      if (_edit){ 
        TextEditParams p; 
        p.title="Password"; 
        p.initial=_pass; 
        p.maxLen=64; 
        p.mask=true; 
        _edit->open(p, [this](bool ok, const String& val){ 
          if (ok) _pass=val; 
          this->draw(); // Перерисовать после закрытия редактора
        }); 
      }
    }
    else if (_sel == 2) { // APPLY
      // Сохранить новые настройки и завершить экран
      _wifi->setStoredSsid(_ssid);
      _wifi->setStoredPass(_pass);
      _wifi->saveConfig();
      _done = true;
    }
    else if (_sel == 3) { // BACK
      _done = true;
    }
  }
}

// Конец WiFiSetup.cpp