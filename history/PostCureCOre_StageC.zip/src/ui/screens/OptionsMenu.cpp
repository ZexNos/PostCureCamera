#include "ui/screens/OptionsMenu.h"
#include "drivers/DisplayST7789.h"
#include "drivers/Encoder.h"
#include "config/Colors.h" // <-- Все константы отсюда

void OptionsMenu::begin(DisplayST7789* d, EncoderDrv* e){
  _disp=d; _enc=e; _sel=0; _pending=RES_NONE;
}

void OptionsMenu::draw(){
  if (!_disp) return;
  auto& t = _disp->gfx();
  // Использует константы UI_W, UI_H, UI_BAR_H из Colors.h
  t.fillRect(0, UI_BAR_H, UI_W, UI_H-UI_BAR_H, COL_BG);

  drawHeader();
  drawList();
}

void OptionsMenu::drawHeader(){
  auto& t = _disp->gfx();
  t.setTextSize(2);
  t.setTextColor(COL_TEXT, COL_BG);
  t.setCursor(6, UI_BAR_H + 6);
  t.print("OPTIONS");
}

void OptionsMenu::drawList(){
  auto& t = _disp->gfx();
  const int top = UI_BAR_H + 30;
  const int rowH = 16;
  // Использует константы UI_W, UI_H, UI_BAR_H из Colors.h
  t.fillRect(0, top-2, UI_W, UI_H-(top-2), COL_BG);

  for (uint8_t i=0; i<3; ++i) drawRow(i, i==_sel);
}

void OptionsMenu::drawRow(uint8_t i, bool sel){
  auto& t = _disp->gfx();
  const int top = UI_BAR_H + 30;
  const int rowH = 16;
  const int y = top + i*rowH;
  
  uint16_t bg = sel ? COL_TILE : COL_BG;
  uint16_t ol = sel ? COL_ACCENT : COL_LINE;

  // Использует константу UI_W из Colors.h
  t.fillRoundRect(6,y-2, UI_W-12, rowH+2, 3, bg);
  t.drawRoundRect(6,y-2, UI_W-12, rowH+2, 3, ol);

  t.setTextSize(1);
  t.setTextColor(sel ? COL_ACCENT : COL_TEXT, bg);
  t.setCursor(12, y+4);

  switch (i) {
    case 0: t.print("Wi-Fi Settings"); break;
    case 1: t.print("MQTT Settings"); break;
    case 2: t.print("Back to Home"); break;
  }
}

void OptionsMenu::tick(){
  if (!_enc) return;
  bool redraw = false;

  if (_enc->right()){ if (_sel < 2) _sel++; redraw=true; }
  if (_enc->left()){  if (_sel > 0) _sel--; redraw=true; }

  if (_enc->click()){
    if (_sel == 0)      _pending = RES_OPEN_WIFI;
    else if (_sel == 1) _pending = RES_OPEN_MQTT;
    else if (_sel == 2) _pending = RES_BACK;
  }
  
  if (redraw) drawList();
}

OptionsMenu::Result OptionsMenu::takeResult(){
  Result r = _pending;
  _pending = RES_NONE;
  return r;
}