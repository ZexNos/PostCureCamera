#pragma once
#include <Arduino.h>
class DisplayST7789;
class EncoderDrv;
class WiFiManager;
class TextEditOverlay;

class WiFiSetup {
public:
  enum Result : uint8_t { RES_NONE=0, RES_SAVE, RES_BACK };

  // Функция, на которую жалуется компоновщик
  void begin(DisplayST7789* d, EncoderDrv* e, WiFiManager* w);
  void setEditor(TextEditOverlay* ed);   // подключить общий редактор

  void draw();
  void tick();
  // 👈 ИСПРАВЛЕНО: Определение isDone() перенесено сюда для устранения ошибки redefinition
  bool isDone() const { return _done; }

private:
  void drawList();
  void drawRow(uint8_t i, bool sel);
  void drawHeader();
  // 👈 ИСПРАВЛЕНО: Добавлена декларация drawFooter()
  void drawFooter();

  DisplayST7789* _disp=nullptr;
  EncoderDrv* _enc=nullptr;
  WiFiManager* _wifi=nullptr;
  TextEditOverlay* _edit=nullptr;

  // поля
  String _ssid, _pass;
  uint8_t _sel=0;    // 0=SSID,1=PASS,2=Save,3=Back
  bool _done=false;
};