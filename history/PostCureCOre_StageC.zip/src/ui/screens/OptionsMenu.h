#pragma once
#include <Arduino.h>
class DisplayST7789;
class EncoderDrv;

class OptionsMenu {
public:
  enum Result : uint8_t { RES_NONE=0, RES_OPEN_WIFI, RES_OPEN_MQTT, RES_BACK };

  void begin(DisplayST7789* d, EncoderDrv* e);
  void draw();
  void tick();
  Result takeResult();

private:
  // 👈 ИСПРАВЛЕНО: Добавлена декларация drawFooter()
  void drawList();
  void drawRow(uint8_t i, bool selected);
  void drawHeader();
  void drawFooter(); 

  DisplayST7789* _disp = nullptr;
  EncoderDrv* _enc  = nullptr;

  uint8_t _sel = 0;       // 0=Wi-Fi, 1=MQTT, 2=Back
  Result  _pending = RES_NONE;
};