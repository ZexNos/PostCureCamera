#include "ui/UiRouter.h"

// экраны и виджеты
#include "ui/screens/RunView.h"
#include "ui/screens/OptionsMenu.h"
#include "ui/screens/WiFiSetup.h"
#include "ui/screens/MqttSettings.h"
#include "ui/widgets/TextEdit.h" // 👈 Здесь определен глобальный TextEdit

// drivers & services
#include "drivers/DisplayST7789.h"
#include "drivers/Encoder.h"
#include "services/wifi/WiFiManager.h"
#include "services/mqtt/MqttManager.h"

#include "config/Colors.h"  // Для COL_BG

#ifndef UI_W
  #define UI_W 160
#endif
#ifndef UI_H
  #define UI_H 128
#endif
#ifndef COL_BG
  #define COL_BG 0x0000 // Black
#endif


void UiRouter::begin(DisplayST7789* d, EncoderDrv* e, WiFiManager* wifi, MqttManager* mqtt){
  _d = d; _e = e; _wifi = wifi; _mqtt = mqtt;

  // Инициализация статических экземпляров экранов
  static RunView     homeInst;
  _home = &homeInst;
  _home->begin(_d, _e);

#if !SAFE_MODE
  // 👈 ИСПРАВЛЕНИЕ: Используем глобальный объект TextEdit, объявленный в TextEdit.cpp
  _editor = &TextEdit; 
  
  static OptionsMenu       optsInst;
  static WiFiSetup         wifiInst;
  static MqttSettingsScreen mqttInst;

  _opts       = &optsInst;
  _wifiScreen = &wifiInst;
  _mqttScreen = &mqttInst;

  _opts->begin(_d, _e);

  // Передаем TextEdit в экраны, которым он нужен
  _wifiScreen->begin(_d, _e, _wifi);
  _wifiScreen->setEditor(_editor); 

  _mqttScreen->begin(_d, _e, _mqtt, _editor); 
#endif

  // Начинаем с домашнего экрана
  _cur = S_HOME;
  _home->draw();
}

/**
 * @brief Метод, который принудительно открывает экран по enum
 * @param s Экран
 */
void UiRouter::open(Screen s){
#if SAFE_MODE
  // В SAFE MODE принудительно держим домашний экран
  _cur = S_HOME;
  _home->draw();
#else
  _cur = s;
  switch (_cur){
    case S_HOME:    _home->draw(); break;
    case S_OPTIONS: _opts->draw(); break;
    case S_WIFI:    _wifiScreen->draw(); break; // WiFiSetup::draw() отрисовывает все сам
    case S_MQTT:    _mqttScreen->drawStatic(); break; // MqttSettingsScreen::drawStatic() отрисовывает все сам
    default: ; // Игнорируем неизвестные экраны
  }
#endif
}

/**
 * @brief Основной цикл роутера, обрабатывает ввод и переходы
 */
void UiRouter::tick(){
#if SAFE_MODE
  if (_home) _home->tick();
  return;
#else
  // 1. Обработка ввода и логика текущего экрана
  // NOTE: TextEditOverlay::tick() вызывается из App::tick() ДО UiRouter::tick()
  
  // Если модальное окно активно, мы НЕ вызываем tick() текущего экрана,
  // чтобы избежать обработки энкодера
  if (_editor && _editor->isActive()){
    // Только перерисовка модального окна поверх
    _editor->draw();
    return;
  }
  
  switch (_cur){
    case S_HOME:    if (_home)       _home->tick();       break;
    case S_OPTIONS: if (_opts)       _opts->tick();       break;
    case S_WIFI:    if (_wifiScreen) _wifiScreen->tick(); break;
    case S_MQTT:    if (_mqttScreen) _mqttScreen->tick(); break;
    default: ;
  }

  // 2. Обработка действий (переходы)
  
  if (_cur == S_HOME){
    RunView::Action a = _home->takeAction();
    if      (a == RunView::ACT_ENTER_SETUP) enterOptions();
    // TODO: добавить enterCure() и enterDry() после реализации
    // else if (a == RunView::ACT_ENTER_CURE)  enterCure();
    // else if (a == RunView::ACT_ENTER_DRY)   enterDry();
  }
  
  else if (_cur == S_OPTIONS){
    OptionsMenu::Result r = _opts->takeResult();
    if      (r == OptionsMenu::RES_BACK)      enterHome();
    else if (r == OptionsMenu::RES_OPEN_WIFI) enterWiFiSetup();
    else if (r == OptionsMenu::RES_OPEN_MQTT) enterMqttSetup();
  }
  
  // Если экран завершил работу (isDone() == true), возвращаемся в Options
  if (_cur == S_WIFI  && _wifiScreen && _wifiScreen->isDone()) enterOptions();
  if (_cur == S_MQTT  && _mqttScreen && _mqttScreen->isDone()) enterOptions();
#endif
}

/* ------ transitions ------ */

// 👈 КРИТИЧЕСКОЕ ИСПРАВЛЕНИЕ: Полная очистка экрана для устранения просвечивания артефактов
void UiRouter::enterHome(){
    if (_d) _d->gfx().fillRect(0, 0, UI_W, UI_H, COL_BG); 
    _cur = S_HOME;    
    _home->draw();
    _d->drawBottomBarStatic("< > Select    v OK"); // Восстанавливаем хинт
}

void UiRouter::enterOptions(){
#if SAFE_MODE
  _cur = S_HOME; _home->draw();
#else
  _cur = S_OPTIONS; 
  _opts->draw();
  _d->drawBottomBarStatic("< > Select    v OK"); 
#endif
}

void UiRouter::enterCure(){
    // TODO: Реализация
}
void UiRouter::enterDry(){
    // TODO: Реализация
}

void UiRouter::enterWiFiSetup(){
  _cur = S_WIFI;
  _wifiScreen->draw(); // draw() выполняет полную перерисовку
  _d->drawBottomBarStatic(nullptr); // Убираем глобальный хинт
}

void UiRouter::enterMqttSetup(){
  _cur = S_MQTT;
  _mqttScreen->drawStatic(); // drawStatic() выполняет полную перерисовку
  _d->drawBottomBarStatic(nullptr); // Убираем глобальный хинт
}