#pragma once
#include <Adafruit_GFX.h>
#include "Adafruit_ST7789.h"
#include <SPI.h>
#include "config/Colors.h"

class DisplayST7789 {
public:
  // ... (конструктор и публичные методы)

  DisplayST7789(uint8_t cs, uint8_t dc, uint8_t rst,
                uint8_t sclk, uint8_t mosi)
  : _tft(cs, dc, rst), _cs(cs), _dc(dc), _rst(rst), _sclk(sclk), _mosi(mosi) {}

  void begin();
  inline Adafruit_ST7789& gfx() { return _tft; } // Определено как inline!

  void clear();
  void clearBody();
  void drawTopBarStatic();
  void updateTopBar(bool wifi, bool mqtt, bool heat, bool uv);
  void drawBottomBarStatic(const char* hint);
  
  void setInverted(bool inv);
  void printSmall(int16_t x, int16_t y, const char* text, uint16_t color);
  void fill(uint16_t color);
  
private:
  Adafruit_ST7789 _tft;
  uint8_t _cs,_dc,_rst,_sclk,_mosi;
  // Кэш состояния верхней полосы
  bool _tbWifi=false, _tbMqtt=false, _tbHeat=false, _tbUV=false;
  
  void _drawWifiIcon(int16_t x, int16_t y, bool on);
  void _drawDotIcon(int16_t x, int16_t y, bool on);
  void _drawHeatIcon(int16_t x, int16_t y, bool on); // 👈 ДОБАВЛЕНО
  void _drawUvIcon(int16_t x, int16_t y, bool on);   // 👈 ДОБАВЛЕНО
};