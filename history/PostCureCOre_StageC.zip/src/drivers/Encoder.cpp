// drivers/Encoder.cpp

#include "drivers/Encoder.h"
#include "config/Pins.h" // Для PIN_ENC_*

void EncoderDrv::begin() {
  pinMode(PIN_ENC_BTN, INPUT_PULLUP);

  // Тип энкодера: стабильный вариант для большинства модулей
  _enc.setEncType(EB_STEP4_LOW);

  // Тайминги из библиотеки (настройка)
  _enc.setHoldTimeout(600);
  _enc.setClickTimeout(350);
  _enc.setBtnLevel(LOW);          // кнопка с PULLUP
}

void EncoderDrv::tick() {
  // КРИТИЧЕСКОЕ ИСПРАВЛЕНИЕ:
  // Сброс флагов происходит только ЗДЕСЬ, в начале цикла tick().
  // Это гарантирует, что все события сбрасываются ОДИН раз за цикл App::tick().
  _evLeft = _evRight = _evClick = _evHold = false; 

  _enc.tick();

  // Сохраняем флаги, установленные библиотекой
  if (_enc.right()) _evRight = true;
  if (_enc.left())  _evLeft  = true;
  if (_enc.click()) _evClick = true;
  if (_enc.hold())  _evHold  = true;
}

// КРИТИЧЕСКОЕ ИСПРАВЛЕНИЕ: Геттеры теперь ТОЛЬКО возвращают состояние,
// не сбрасывая флаги. Флаги сбрасываются только в начале tick().
bool EncoderDrv::left()  { return _evLeft; }
bool EncoderDrv::right() { return _evRight; }
bool EncoderDrv::click() { return _evClick; }
bool EncoderDrv::hold()  { return _evHold; }