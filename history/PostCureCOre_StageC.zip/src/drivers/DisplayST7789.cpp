#include "drivers/DisplayST7789.h"
#include "config/Colors.h"
#include "config/Pins.h"
#include "Adafruit_ST7789.h"
#include <SPI.h>

// Для удобства, берем константы из Colors.h
#ifndef UI_W
  #define UI_W 160
#endif
#ifndef UI_H
  #define UI_H 128
#endif
#ifndef UI_BAR_H
  #define UI_BAR_H 16
#endif

// ==================================================================================
// ФУНКЦИЯ BEGIN (ИНИЦИАЛИЗАЦИЯ)
// ==================================================================================

void DisplayST7789::begin() {
  // 1. Инициализация SPI
#ifdef PIN_TFT_MISO
  SPI.begin(_sclk, PIN_TFT_MISO, _mosi); 
#else
  SPI.begin(_sclk, -1, _mosi);
#endif
  
  // 2. Инициализация дисплея ST7789
  _tft.init(UI_W, UI_H); 
  _tft.setRotation(UI_ROTATION);
  _tft.fillScreen(COL_BG);
  
  // 3. Рисуем статические элементы
  drawTopBarStatic();
  drawBottomBarStatic("< > Select    v OK");
}

// ==================================================================================
// ФУНКЦИИ ОЧИСТКИ И УПРАВЛЕНИЯ
// ==================================================================================

void DisplayST7789::clear() { 
  _tft.fillScreen(COL_BG); 
}

void DisplayST7789::clearBody() { 
  // Очистка тела UI (между верхней и нижней полосой)
  _tft.fillRect(0, UI_BAR_H, UI_W, UI_H - 2 * UI_BAR_H, COL_BG); 
}

void DisplayST7789::fill(uint16_t color) {
    _tft.fillScreen(color);
}

void DisplayST7789::setInverted(bool inv) {
    if (inv) {
        _tft.invertDisplay(true);
    } else {
        _tft.invertDisplay(false);
    }
}

// ==================================================================================
// ВЕРХНЯЯ ПОЛОСА (Top Bar)
// ==================================================================================

void DisplayST7789::drawTopBarStatic() {
  _tft.fillRect(0, 0, UI_W, UI_BAR_H, COL_BAR); // Фон
  _tft.drawFastHLine(0, UI_BAR_H - 1, UI_W, COL_LINE); // Нижняя граница

  _tft.setTextSize(1);
  _tft.setTextColor(COL_TEXT_DIM, COL_BAR);
  _tft.setCursor(6, 4);
  _tft.print("POST-CURE"); // Заголовок
}

/**
 * @brief Перерисовывает иконки в верхней полосе (статус Wi-Fi, MQTT и т.д.)
 */
void DisplayST7789::updateTopBar(bool wifi, bool mqtt, bool heat, bool uv) {
    // Координаты для иконок (справа налево): UV, HEAT, MQTT, WIFI
    const int x_uv = UI_W - 6;
    const int x_heat = x_uv - 14;
    const int x_mqtt = x_heat - 14;
    const int x_wifi = x_mqtt - 14;
    const int y_icon = UI_BAR_H / 2 + 1; // Центр по высоте

    // 1. WiFi: Обновление только при изменении состояния
    if (wifi != _tbWifi) {
        _drawWifiIcon(x_wifi, y_icon, wifi);
        _tbWifi = wifi;
    }

    // 2. MQTT: Обновление только при изменении состояния
    if (mqtt != _tbMqtt) {
        _drawDotIcon(x_mqtt, y_icon, mqtt);
        _tbMqtt = mqtt;
    }
    
    // 3. Heat: Обновление только при изменении состояния
    if (heat != _tbHeat) {
        _drawHeatIcon(x_heat, y_icon, heat);
        _tbHeat = heat;
    }
    
    // 4. UV: Обновление только при изменении состояния
    if (uv != _tbUV) {
        _drawUvIcon(x_uv, y_icon, uv);
        _tbUV = uv;
    }
}

// ==================================================================================
// НИЖНЯЯ ПОЛОСА (Bottom Bar)
// ==================================================================================

void DisplayST7789::drawBottomBarStatic(const char* hint) {
  _tft.fillRect(0, UI_H - UI_BAR_H, UI_W, UI_BAR_H, COL_BAR); // Фон
  _tft.drawFastHLine(0, UI_H - UI_BAR_H, UI_W, COL_LINE); // Верхняя граница

  _tft.setTextSize(1);
  _tft.setTextColor(COL_TEXT_DIM, COL_BAR);
  _tft.setCursor(6, UI_H - UI_BAR_H + 4);
  _tft.print(hint); // Подсказка
}

// ==================================================================================
// РИСОВАНИЕ ИКОНОК (ИСПРАВЛЕНЫ drawArc)
// ==================================================================================

/**
 * @brief Рисует иконку Wi-Fi. (Используя drawPixel вместо drawArc)
 */
void DisplayST7789::_drawWifiIcon(int16_t x, int16_t y, bool on) {
  uint16_t color = on ? COL_ACCENT : COL_TEXT_DIM;
  uint16_t bg    = COL_BAR;
  
  // Очистка области
  _tft.fillRect(x - 8, y - 6, 16, 12, bg);

  // Точка (центр)
  _tft.drawPixel(x, y + 4, color); 

  // Внутренняя "дуга" (R=2-3, примерно 135-45 град)
  _tft.drawPixel(x-2, y+2, color);
  _tft.drawPixel(x-3, y+1, color);
  _tft.drawPixel(x+2, y+2, color);
  _tft.drawPixel(x+3, y+1, color);

  // Средняя "дуга" (R=5-6, примерно 135-45 град)
  _tft.drawPixel(x-4, y, color);
  _tft.drawPixel(x-5, y-1, color);
  _tft.drawPixel(x+4, y, color);
  _tft.drawPixel(x+5, y-1, color);
  
  // Внешняя "дуга" (R=7-8, примерно 135-45 град)
  _tft.drawPixel(x-6, y-2, color);
  _tft.drawPixel(x-7, y-3, color);
  _tft.drawPixel(x+6, y-2, color);
  _tft.drawPixel(x+7, y-3, color);
}

/**
 * @brief Рисует иконку статуса (маленькая точка для MQTT).
 */
void DisplayST7789::_drawDotIcon(int16_t x, int16_t y, bool on) {
  uint16_t color = on ? COL_ACCENT : COL_TEXT_DIM;
  uint16_t bg    = COL_BAR;
  
  // Очистка области
  _tft.fillRect(x - 4, y - 6, 8, 12, bg);
  
  // Точка (очистка фона и рисование)
  _tft.fillCircle(x, y, 3, color);
  _tft.drawCircle(x, y, 3, color);
}

/**
 * @brief Рисует иконку нагрева.
 */
void DisplayST7789::_drawHeatIcon(int16_t x, int16_t y, bool on) {
  uint16_t fgOn  = COL_WARN;
  uint16_t fgOff = COL_TEXT_DIM;
  uint16_t color = on ? fgOn : fgOff;
  uint16_t bg    = COL_BAR;
  
  // Очистка области
  _tft.fillRect(x-5, y-5, 10, 10, bg);

  // Иконка (стилизованная спираль/пламя)
  // Основные линии
  _tft.drawFastHLine(x-4, y, 8, color);
  _tft.drawFastVLine(x-4, y-2, 4, color);
  _tft.drawFastVLine(x+3, y-2, 4, color);
  
  // "Пламя" или "нагрев"
  _tft.drawLine(x-4, y-2, x-2, y-4, color);
  _tft.drawLine(x-1, y-2, x+1, y-4, color);
  _tft.drawLine(x+3, y-2, x+5, y-4, color);
}


/**
 * @brief Рисует иконку УФ.
 */
void DisplayST7789::_drawUvIcon(int16_t x, int16_t y, bool on) {
  uint16_t fgOn  = COL_ACCENT;
  uint16_t fgOff = COL_TEXT_DIM;
  uint16_t color = on ? fgOn : fgOff;
  uint16_t bg    = COL_BAR;
  
  // Очистка области
  _tft.fillRect(x - 5, y - 5, 10, 10, bg);

  // Иконка (стилизованная лампочка / луч)
  _tft.drawRect(x-3, y-5, 6, 6, color); // Прямоугольник (лампа)
  _tft.drawFastHLine(x-1, y+2, 2, color); // Соединение
  
  // Лучи
  _tft.drawLine(x-4, y+4, x-7, y+7, color); 
  _tft.drawLine(x+4, y+4, x+7, y+7, color);
  
  // Луч по центру
  _tft.drawLine(x, y+4, x, y+7, color);
}

// ==================================================================================
// ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
// ==================================================================================

/**
 * @brief Выводит текст маленьким шрифтом. (Для отладки или дополнительной информации)
 */
void DisplayST7789::printSmall(int16_t x, int16_t y, const char* text, uint16_t color) {
    _tft.setTextSize(1);
    _tft.setTextColor(color, COL_BG);
    _tft.setCursor(x, y);
    _tft.print(text);
}