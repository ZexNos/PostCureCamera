#include "self.h"

void* EB_self = nullptr;