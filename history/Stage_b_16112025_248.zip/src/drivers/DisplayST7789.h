#pragma once
#include <Arduino.h>
#include <SPI.h>
#include <Adafruit_GFX.h>
#include "Adafruit_ST7789.h"
#include "config/Pins.h"
#include "config/Colors.h"

class DisplayST7789 {
public:
  DisplayST7789();

  void begin();
  void setInverted(bool inv);     // инверт цветов (true/false)

  void clear();
  void clearBody();

  void drawTopBarStatic();
  void updateTopBar(bool wifi, bool mqtt, bool heater, bool uv);

  void printSmall(int16_t x, int16_t y, const char* text, uint16_t color = COL_TEXT);
  void fill(uint16_t color);

  Adafruit_ST7789& gfx();

private:
  Adafruit_ST7789 _tft;

  // Кэш значков шапки
  bool _tbWifi  = false;
  bool _tbMqtt  = false;
  bool _tbHeat  = false;
  bool _tbUV    = false;

  // Иконки
  void drawWifiIcon(int16_t x, int16_t y, bool on);  // Wi-Fi: off=серые дуги+крест, on=оранжевые палки
  void drawDotIcon (int16_t x, int16_t y, bool on);  // MQTT/Heater/UV
};
