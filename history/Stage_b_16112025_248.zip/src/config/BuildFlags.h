#pragma once

// Stage A: keep non-essential subsystems off
#define HAS_WIFI   0
#define HAS_MQTT   0
#define HAS_SENS   0
#define HAS_HEATER 0
#define HAS_UV     0
