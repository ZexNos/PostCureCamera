#include "WiFiSetup.h"
#include "services/wifi/WiFiManager.h"   // реализация сервиса нужна только здесь
#include "config/Colors.h"
#include "config/Pins.h"

const char* WIFISETUP_CHARS =
  "abcdefghijklmnopqrstuvwxyz"
  "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
  "0123456789"
  "-_ .!@#$%";

void WiFiSetup::begin(DisplayST7789* d, EncoderDrv* e, WiFiManager* w){
  tft = d; enc = e; wifi = w;
  _exit = false; sel = 0;
  _ssid = ""; _pass = "";
  mode = Mode::Idle;
}

void WiFiSetup::drawStatic() {
  // полный сброс состояний для корректного повторного входа
  _exit    = false;
  mode     = Mode::Idle;
  sel      = 0;
  _listOff = 0;
  _ssid    = "";
  _pass    = "";
  _charIdx = 0;
  _sub     = PassSub::PickChar;
  _cmdSel  = 0;
  _statusSel = 0;

  // Очистить тело
  tft->clearBody();

  // Заголовок
  tft->gfx().setCursor(6, UI_BAR_H + 12);
  tft->gfx().setTextColor(COL_TEXT);
  tft->gfx().setTextSize(2);
  tft->gfx().print(F("Wi-Fi"));

  tft->gfx().setTextSize(1);
  tft->gfx().setCursor(6, UI_BAR_H + 32);
  tft->gfx().print(F("Scan networks, select SSID"));
  drawFooter(F("Rotate=move  Click=ok  Hold=back"));

  wifi->startScan(true);
  mode = Mode::Scanning;
}

void WiFiSetup::drawFooter(const __FlashStringHelper* text){
  tft->gfx().fillRect(0, UI_H-10, UI_W, 10, COL_BG);
  tft->gfx().setCursor(4, UI_H-9);
  tft->gfx().setTextColor(COL_LINE);
  tft->gfx().setTextSize(1);
  tft->gfx().print(text);
}

void WiFiSetup::ensureListVisible() {
  int n = wifi->apCount();
  if (n <= 0) { _listOff = 0; sel = 0; return; }

  if (sel < 0) sel = 0;
  if (sel > n - 1) sel = n - 1;

  // если sel ушёл выше окна
  if (sel < _listOff) _listOff = sel;

  // если sel ушёл ниже окна
  if (sel >= _listOff + VISIBLE) _listOff = sel - (VISIBLE - 1);

  // clamp offset чтобы окно было валидным
  if (_listOff < 0) _listOff = 0;
  if (_listOff > max(0, n - VISIBLE)) _listOff = max(0, n - VISIBLE);
}

void WiFiSetup::drawList() {
  const int y0 = UI_BAR_H + 44;
  tft->gfx().fillRect(0, y0, UI_W, UI_H - y0 - 10, COL_BG);

  int n = wifi->apCount();
  if (n <= 0) {
    tft->gfx().setCursor(6, y0 + 2);
    tft->gfx().setTextColor(COL_LINE);
    tft->gfx().print(F("No networks"));
    drawFooter(F("Hold=back  Click=rescan"));
    return;
  }

  ensureListVisible();

  int shown = min(VISIBLE, n - _listOff);
  int y = y0 + 2;

  for (int i = 0; i < shown; i++) {
    int idx = _listOff + i;

    if (sel == idx) {
      tft->gfx().fillRect(4, y-2, UI_W-8, 12, COL_TILE);
      tft->gfx().setTextColor(COL_TEXT);
    } else {
      tft->gfx().setTextColor(COL_LINE);
    }

    tft->gfx().setCursor(8, y);
    tft->gfx().print(wifi->ssidAt(idx));

    // палочки справа (0..4)
    int bars = wifi->rssiBarsAt(idx);
    int bx = UI_W - 20; int by = y - 1;
    for (int b=0;b<4;b++){
      int h = 2 + b*2;
      uint16_t col = (b < bars) ? COL_ACCENT : COL_LINE;
      tft->gfx().fillRect(bx + b*3, by + (8-h), 2, h, col);
    }
    y += 12;
  }

  drawFooter(F("Click=select  Hold=back"));
}

void WiFiSetup::drawPass() {
  const int y0 = UI_BAR_H + 44;
  tft->gfx().fillRect(0, y0, UI_W, UI_H - y0 - 10, COL_BG);

  // SSID и маска пароля
  tft->gfx().setTextColor(COL_TEXT); tft->gfx().setTextSize(1);
  tft->gfx().setCursor(6, y0 + 2);
  tft->gfx().print(F("SSID: ")); tft->gfx().print(_ssid);

  tft->gfx().setCursor(6, y0 + 16);
  tft->gfx().print(F("PASS: "));
  for (size_t i=0;i<_pass.length();++i) tft->gfx().print('*');

  if (_sub == PassSub::PickChar) {
    tft->gfx().setCursor(6, y0 + 30);
    tft->gfx().print(F("Char: "));
    tft->gfx().print(WIFISETUP_CHARS[_charIdx]);

    const char* cmds[4] = {"Add","Del","OK","Back"};
    int x = 8; int y = y0 + 44;
    for (int i=0;i<4;i++){
      tft->gfx().setTextColor(COL_LINE);
      tft->gfx().setCursor(x, y);
      tft->gfx().print(cmds[i]);
      x += (i==1 ? 28 : 24);
    }
    drawFooter(F("Rotate=char  Click=append  Hold=to [Add/Del/OK/Back]"));
  } else {
    const char* cmds[4] = {"[Add]","[Del]","[OK]","[Back]"};
    int x = 8; int y = y0 + 44;
    for (int i=0;i<4;i++){
      int w = (i==1?24:(i==2?20:20));
      if (_cmdSel == i) {
        tft->gfx().fillRect(x-2, y-2, w, 12, COL_TILE);
        tft->gfx().setTextColor(COL_TEXT);
      } else {
        tft->gfx().setTextColor(COL_LINE);
      }
      tft->gfx().setCursor(x, y);
      tft->gfx().print(cmds[i]);
      x += (i==1 ? 28 : 24);
    }
    drawFooter(F("Rotate=select  Click=run  Hold=back to Char"));
  }
}

void WiFiSetup::drawStatus() {
  const int y0 = UI_BAR_H + 44;
  tft->gfx().fillRect(0, y0, UI_W, UI_H - y0 - 10, COL_BG);

  tft->gfx().setTextColor(COL_TEXT); tft->gfx().setTextSize(1);
  tft->gfx().setCursor(6, y0 + 2);
  auto s = wifi->state();
  if (s == WiFiManager::State::Connecting) {
    tft->gfx().print(F("Connecting..."));
  } else if (s == WiFiManager::State::Connected) {
    tft->gfx().print(F("Connected: ")); tft->gfx().print(wifi->currentSsid());
    tft->gfx().setCursor(6, y0 + 16); tft->gfx().print(F("IP: ")); tft->gfx().print(wifi->ipStr());
  } else if (s == WiFiManager::State::Failed) {
    tft->gfx().print(F("Link lost / Failed"));
  } else if (s == WiFiManager::State::Idle) {
    tft->gfx().print(F("Idle"));
  }

  // Кнопки статуса: [OK] [Forget]
  const char* sbtn[2] = {"[OK]","[Forget]"};
  int x = 8; int y = y0 + 34;
  for (int i=0;i<2;i++){
    int w = (i==0 ? 20 : 44);
    if (_statusSel == i) {
      tft->gfx().fillRect(x-2, y-2, w, 12, COL_TILE);
      tft->gfx().setTextColor(COL_TEXT);
    } else {
      tft->gfx().setTextColor(COL_LINE);
    }
    tft->gfx().setCursor(x, y);
    tft->gfx().print(sbtn[i]);
    x += (i==0 ? 28 : 56);
  }
  drawFooter(F("Rotate=select  Click=run  Hold=back"));
}

void WiFiSetup::tick() {
  // enc.tick() вызывается в App::tick()

  switch (mode) {
    case Mode::Scanning: {
      if (wifi->scanReady()) {
        sel = 0;
        _listOff = 0;
        mode = Mode::List;
        drawList();
      }
      if (enc->hold()) { _exit = true; }
    } break;

    case Mode::List: {
      int n = wifi->apCount();
      bool moved = false;

      if (enc->right() && sel < n-1) { sel++; moved = true; }
      if (enc->left()  && sel > 0)   { sel--; moved = true; }

      if (moved) {
        ensureListVisible();
        drawList();
      }

      if (enc->click() && n>0) {
        _ssid = wifi->ssidAt(sel);
        _pass = "";
        _charIdx = 0;
        _sub = PassSub::PickChar;
        _cmdSel = 0;
        mode = Mode::PassInput;
        drawPass();
      }
      if (enc->hold()) { _exit = true; }
    } break;

    case Mode::PassInput: {
      if (_sub == PassSub::PickChar) {
        bool redraw = false;
        const int L = strlen(WIFISETUP_CHARS);
        if (enc->right()) { _charIdx++; if (_charIdx >= L) _charIdx = 0;   redraw = true; }
        if (enc->left())  { _charIdx--; if (_charIdx < 0)  _charIdx = L-1; redraw = true; }
        if (enc->click()) { _pass += WIFISETUP_CHARS[_charIdx];             redraw = true; }
        if (enc->hold())  { _sub = PassSub::CmdRow; _cmdSel = 0; redraw = true; }
        if (redraw) drawPass();
      } else {
        bool redraw = false;
        if (enc->right() && _cmdSel < 3) { _cmdSel++; redraw = true; }
        if (enc->left()  && _cmdSel > 0) { _cmdSel--; redraw = true; }

        if (enc->click()) {
          switch (_cmdSel) {
            case 0: _pass += WIFISETUP_CHARS[_charIdx]; redraw = true; break;           // Add
            case 1: if (_pass.length()) _pass.remove(_pass.length()-1); redraw = true; break; // Del
            case 2: // OK → подключаемся
              wifi->setCredentials(_ssid, _pass);
              wifi->connect();
              mode = Mode::Connecting;
              drawStatus();
              break;
            case 3: _exit = true; break;  // Back
          }
        }
        if (enc->hold()) { _sub = PassSub::PickChar; redraw = true; }
        if (redraw && mode == Mode::PassInput) drawPass();
      }
    } break;

    case Mode::Connecting: {
      if (wifi->state() == WiFiManager::State::Connected ||
          wifi->state() == WiFiManager::State::Failed) {
        _statusSel = 0;  // по умолчанию на OK
        mode = Mode::Status;
        drawStatus();
      }
      if (enc->hold()) { _exit = true; }
    } break;

    case Mode::Status: {
      bool redraw = false;
      if (enc->right() && _statusSel < 1) { _statusSel++; redraw = true; }
      if (enc->left()  && _statusSel > 0) { _statusSel--; redraw = true; }

      if (enc->click()) {
        if (_statusSel == 0) {
          _exit = true;                     // OK → выйти в RunView
        } else {
          // Forget → стереть креды и перезапустить
          wifi->disconnect(true);           // erase NVS
          tft->clearBody();
          tft->gfx().setCursor(6, UI_BAR_H + 20);
          tft->gfx().setTextColor(COL_TEXT);
          tft->gfx().print(F("Wi-Fi creds cleared"));
          tft->gfx().setCursor(6, UI_BAR_H + 34);
          tft->gfx().print(F("Restarting..."));
          delay(300);
          ESP.restart();
        }
      }
      if (enc->hold()) { _exit = true; }
      if (redraw) drawStatus();
    } break;

    case Mode::Idle:
    default:
      break;
  }
}
