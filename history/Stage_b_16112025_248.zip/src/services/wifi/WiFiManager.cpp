#include "WiFiManager.h"

void WiFiManager::begin() {
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  WiFi.persistent(true);

  attachEvents();                 // события Wi-Fi → мгновенная реакция

  // Автоподключение к сохранённым кредам (NVS)
  WiFi.begin();                   // без аргументов → к последней сети
  enter(State::Connecting);
}

void WiFiManager::attachEvents() {
  // ESP32 core 3.3.2: подписываемся строго на ARDUINO_EVENT_* (arduino_event_id_t)
  WiFi.onEvent(
    [this](arduino_event_id_t /*event*/, arduino_event_info_t /*info*/){
      enter(State::Connected);
    },
    ARDUINO_EVENT_WIFI_STA_GOT_IP
  );

  WiFi.onEvent(
    [this](arduino_event_id_t /*event*/, arduino_event_info_t /*info*/){
    // потеря линка (в т.ч. блокировка на роутере) → сразу Failed
      enter(State::Failed);
    },
    ARDUINO_EVENT_WIFI_STA_DISCONNECTED
  );
}

void WiFiManager::tick() {
  switch (_state) {
    case State::Scanning: {
      if (_scanAsync) {
        int res = WiFi.scanComplete();
        if (res == WIFI_SCAN_FAILED) {
          enter(State::Idle);
        } else if (res >= 0) {
          handleScanDone();
        }
      }
    } break;

    case State::Connecting: {
      // события выставят Connected/Failed, но подстрахуемся
      if (WiFi.status() == WL_CONNECTED) {
        enter(State::Connected);
      } else if (millis() - _stateSince > 12000UL) {
        WiFi.disconnect();   // не чистим NVS, просто прерываем
        enter(State::Failed);
      }
    } break;

    case State::Connected:
    case State::Failed:
      handleLinkWatch();
      break;

    case State::ScanReady:
    case State::Idle:
    default:
      break;
  }
}

bool WiFiManager::startScan(bool showHidden) {
  if (_state == State::Scanning) return false;
  _ssidCount = 0;
  WiFi.scanDelete();
  WiFi.scanNetworks(true /*async*/, showHidden /*hidden*/, false /*passive*/);
  _scanAsync = true;
  enter(State::Scanning);
  return true;
}

void WiFiManager::handleScanDone() {
  int n = WiFi.scanComplete();
  _ssidCount = 0;
  for (int i = 0; i < n && i < MAX_APS; ++i) {
    String s = WiFi.SSID(i);
    if (!s.length()) s = F("<Hidden>");
    _ssidBuf[_ssidCount] = s;
    _bars[_ssidCount] = rssiToBars(WiFi.RSSI(i));
    _ssidCount++;
  }
  WiFi.scanDelete();
  enter(State::ScanReady);
}

void WiFiManager::setCredentials(const String& ssid, const String& pass) {
  _wantSsid = ssid;
  _wantPass = pass;
}

bool WiFiManager::connect() {
  if (_wantSsid.isEmpty()) return false;
  WiFi.disconnect();
  WiFi.begin(_wantSsid.c_str(), _wantPass.c_str());
  enter(State::Connecting);
  return true;
}

void WiFiManager::disconnect(bool erase) {
  WiFi.disconnect(erase, erase);   // erase=true → Forget (очистка NVS)
  enter(State::Idle);
}

void WiFiManager::handleLinkWatch() {
  // Быстрый auto-reconnect при потере линка
  if (WiFi.status() != WL_CONNECTED) {
    if (millis() - _lastReconnectTry > _reconnectPeriodMs) {
      _lastReconnectTry = millis();
      if (_wantSsid.isEmpty()) {
        WiFi.reconnect();  // к сохранённым
      } else {
        WiFi.begin(_wantSsid.c_str(), _wantPass.c_str());
      }
      enter(State::Connecting);
    }
  }
}

int WiFiManager::rssiToBars(long rssi) {
  if (rssi > -55) return 4;
  if (rssi > -65) return 3;
  if (rssi > -75) return 2;
  if (rssi > -85) return 1;
  return 0;
}

void WiFiManager::enter(State s) {
  _state = s;
  _stateSince = millis();
}
