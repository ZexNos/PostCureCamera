#pragma once
#include <Arduino.h>
#include "drivers/DisplayST7789.h"
#include "drivers/Encoder.h"

// форвард-декларация, чтобы не тянуть сервис сюда и не зациклиться
class WiFiManager;

class WiFiSetup {
public:
  void begin(DisplayST7789* d, EncoderDrv* e, WiFiManager* w);
  void drawStatic();
  void tick();
  bool isDone() const { return _exit; }

private:
  enum class Mode   : uint8_t { Idle, Scanning, List, PassInput, Connecting, Status };
  enum class PassSub: uint8_t { PickChar, CmdRow };   // выбор символа / выбор команды

  void drawList();
  void drawFooter(const __FlashStringHelper* text);
  void drawPass();
  void drawStatus();
  void ensureListVisible();       // поддерживает sel в окне [offset..offset+VISIBLE-1]

  DisplayST7789* tft = nullptr;
  EncoderDrv*    enc = nullptr;
  WiFiManager*   wifi = nullptr;

  Mode    mode   = Mode::Idle;
  bool    _exit  = false;

  // Список сетей + прокрутка
  static constexpr int VISIBLE = 5;
  int8_t  sel        = 0;       // выбранный индекс (0..apCount-1)
  int8_t  _listOff   = 0;       // смещение первого видимого элемента

  // Ввод пароля
  String  _ssid;
  String  _pass;
  int     _charIdx = 0;
  PassSub _sub     = PassSub::PickChar;
  int8_t  _cmdSel  = 0;         // 0..3 → [Add][Del][OK][Back]

  // Status экран
  int8_t  _statusSel = 0;       // 0..1 → [OK] [Forget]
};

// Таблица символов для пароля
extern const char* WIFISETUP_CHARS;
