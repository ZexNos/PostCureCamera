#pragma once
#include <Arduino.h>
#include <WiFi.h>

class WiFiManager {
public:
  static constexpr uint8_t MAX_APS = 16;

  enum class State : uint8_t {
    Idle, Scanning, ScanReady, Connecting, Connected, Failed
  };

  // Жизненный цикл
  void begin();   // STA, автоподключение к сохранённым кредам (NVS)
  void tick();    // завершение скана, контроль линка, авто-reconnect

  // Сканирование
  bool   startScan(bool showHidden = true); // true если стартанул, false если уже идёт
  bool   scanReady() const { return _state == State::ScanReady; }
  int    apCount()   const { return _ssidCount; }
  String ssidAt(int i) const { return (i>=0 && i<_ssidCount) ? _ssidBuf[i] : String(); }
  int    rssiBarsAt(int i) const { return (i>=0 && i<_ssidCount) ? _bars[i] : 0; }

  // Подключение
  void   setCredentials(const String& ssid, const String& pass);
  bool   connect();                         // старт подключения к _wantSsid/_wantPass
  void   disconnect(bool erase = false);    // erase=true → стереть NVS (Forget)
  bool   connected() const { return WiFi.status() == WL_CONNECTED; }
  String ipStr() const { return connected() ? WiFi.localIP().toString() : String(F("---")); }
  String currentSsid() const { return connected() ? WiFi.SSID() : _wantSsid; }
  State  state() const { return _state; }

private:
  static int rssiToBars(long rssi);   // реализация в .cpp
  void enter(State s);                // реализация в .cpp
  void handleScanDone();
  void handleLinkWatch();
  void attachEvents();

  State    _state = State::Idle;
  uint32_t _stateSince = 0;

  // скан-кэш
  String   _ssidBuf[MAX_APS];
  uint8_t  _bars[MAX_APS] = {0};
  int      _ssidCount = 0;
  bool     _scanAsync = false;

  // желаемые креды
  String   _wantSsid;
  String   _wantPass;

  // авто-reconnect
  uint32_t _lastReconnectTry = 0;
  uint32_t _reconnectPeriodMs = 8000;
};
