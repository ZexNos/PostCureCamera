#include "app/App.h"
#include "config/Colors.h"

static const uint32_t TOPBAR_PERIOD_MS = 300;

void App::begin() {
  tft.begin();
  tft.setInverted(false);  // нужно инвертировать? поставь true
  enc.begin();
  ui.begin(&tft);
  screenRun.begin(&tft);
  screenWiFi.begin(&tft, &enc, &wifi);
  wifi.begin();

  // Верхняя строка
  tft.drawTopBarStatic();
  tft.updateTopBar(false, false, false, false);
  lastIcons = millis();

  // Стартовый экран
  screenRun.drawStatic();
  screenRun.updateValue(cursor);
}

void App::tick() {
  // Тикаем энкодер ОДИН раз здесь
  enc.tick();
  wifi.tick();

  // Вход в Wi-Fi Setup: hold работает ТОЛЬКО на главном экране
  if (cur == Screen::Run && enc.hold()) {
    cur = Screen::WiFi;
    screenWiFi.drawStatic();      // сброс внутренних флагов и старт скана
  }

  if (cur == Screen::Run) {
    bool changed = false;
    if (enc.left())  { cursor--; changed = true; }
    if (enc.right()) { cursor++; changed = true; }
    if (enc.click()) { cursor = 0; changed = true; }

    if (cursor < -99) cursor = -99;
    if (cursor >  99) cursor =  99;
    if (changed) screenRun.updateValue(cursor);
  } else if (cur == Screen::WiFi) {
    screenWiFi.tick();
    if (screenWiFi.isDone()) {
      cur = Screen::Run;
      screenRun.drawStatic();
      screenRun.updateValue(cursor);
    }
  }

  // Иконки в шапке
  if (millis() - lastIcons >= TOPBAR_PERIOD_MS) {
    tft.updateTopBar(wifi.connected(), false, false, false);
    lastIcons = millis();
  }
}
