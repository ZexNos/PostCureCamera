#include "services/MqttManager.h"

MqttManager* MqttManager::instance = nullptr;

// ----------------------------------------------------------------------------
// INIT
// ----------------------------------------------------------------------------

void MqttManager::begin() {
    instance = this;
    _mqtt.setClient(_wifiClient);
    _mqtt.setServer(MQTT_HOST, MQTT_PORT);
    _mqtt.setCallback(MqttManager::onMessageStatic);
    _lastAttemptMs = millis();
}


// ----------------------------------------------------------------------------
// MESSAGE CALLBACK
// ----------------------------------------------------------------------------

void MqttManager::onMessageStatic(char* topic, byte* payload, unsigned int length) {
    if (instance) instance->onMessage(topic, payload, length);
}

void MqttManager::onMessage(char* topic, byte* payload, unsigned int length) {
    _everReceived = true;
    _lastRxMs = millis();

    // здесь можно обработать команды
    // пример: просто вывод в Serial
    // Serial.printf("MQTT RX [%s]: %.*s\n", topic, length, payload);
}


// ----------------------------------------------------------------------------
// RECONNECT
// ----------------------------------------------------------------------------

void MqttManager::reconnect() {
    if (_mqtt.connected()) return;

    if (millis() - _lastAttemptMs < RECONNECT_INTERVAL) return;
    _lastAttemptMs = millis();

    bool ok = false;

    // Авторизация если указана
    if (strlen(MQTT_USER) > 0) {
        ok = _mqtt.connect("PostCureCameraClient", MQTT_USER, MQTT_PASS);
    } else {
        ok = _mqtt.connect("PostCureCameraClient");
    }

    if (ok) {
        _mqtt.subscribe(MQTT_SUB_COMMAND);
        // можно сразу послать онлайн-флаг
        publishStatus("online");
    }
}


// ----------------------------------------------------------------------------
// TICK
// ----------------------------------------------------------------------------

void MqttManager::tick(bool wifiOK) {

    // без Wi-Fi — всё в нулях
    if (!wifiOK) {
        _connected = false;
        _alive = false;
        return;
    }

    // пробуем подключиться
    if (!_mqtt.connected()) {
        reconnect();
    }

    _connected = _mqtt.connected();

    // если соединены — обслуживаем loop
    if (_connected) {
        _mqtt.loop();
    }

    // определяем alive
    if (_connected && _everReceived) {
        _alive = (millis() - _lastRxMs) < ALIVE_TIMEOUT;
    } else {
        _alive = false;
    }
}


// ----------------------------------------------------------------------------
// PUBLISH HELPERS
// ----------------------------------------------------------------------------

void MqttManager::publishStatus(const String& s) {
    if (_mqtt.connected()) {
        _mqtt.publish(MQTT_PUB_STATUS, s.c_str(), true);
    }
}

void MqttManager::publishPing() {
    if (_mqtt.connected()) {
        _mqtt.publish(MQTT_PUB_PING, "1", false);
    }
}
