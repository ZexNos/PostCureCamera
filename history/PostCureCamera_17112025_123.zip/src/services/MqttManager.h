#pragma once
#include <Arduino.h>
#include <WiFi.h>
#include <PubSubClient.h>
#include "services/NetConfig.h"

class MqttManager {
public:
    void begin();
    void tick(bool wifiOK);

    bool isConnected() const { return _connected; }  // TCP connected
    bool isAlive() const { return _alive; }          // получал входящие?

    void publishStatus(const String& s);
    void publishPing();

private:
    WiFiClient _wifiClient;
    PubSubClient _mqtt;

    bool _connected = false;      // client.connected()
    bool _everReceived = false;   // были входящие
    bool _alive = false;          // жив ли поток

    uint32_t _lastRxMs = 0;       // последнее входящее
    uint32_t _lastAttemptMs = 0;

    static constexpr uint32_t RECONNECT_INTERVAL = 5000;
    static constexpr uint32_t ALIVE_TIMEOUT      = 60000;  // 60 сек без входящих = dead

    void reconnect();
    static void onMessageStatic(char* topic, byte* payload, unsigned int length);
    void onMessage(char* topic, byte* payload, unsigned int length);

    static MqttManager* instance; // для callback'а
};
