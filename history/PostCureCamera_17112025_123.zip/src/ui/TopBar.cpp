#include "ui/TopBar.h"
#include "config/Colors.h"     // цвета и UI_W/UI_BAR_H

void UiTopBar::begin(DisplayST7789* tft) {
    _tft = tft;
}

void UiTopBar::drawStatic(const char* title) {
    if (!_tft) return;

    auto& g = _tft->gfx();

    // фон верхней строки
    g.fillRect(0, 0, UI_W, UI_BAR_H, COL_BAR);
    g.drawLine(0, UI_BAR_H - 1, UI_W, UI_BAR_H - 1, COL_LINE);

    _title = title;
    drawTitle(title);

    // сброс кэша иконок
    _wifi = _mqtt = _heat = _uv = false;
    drawIcons(false, false, false, false);
}

void UiTopBar::update(bool wifi, bool mqtt, bool heater, bool uv) {
    if (!_tft) return;

    // если иконки не изменились — ничего не делаем
    if (wifi == _wifi && mqtt == _mqtt && heater == _heat && uv == _uv)
        return;

    _wifi  = wifi;
    _mqtt  = mqtt;
    _heat  = heater;
    _uv    = uv;

    drawIcons(wifi, mqtt, heater, uv);
}

// ─────────────────────────────────────────────────────────────
// ЦЕНТРОВАНИЕ ТИТУЛА
// ─────────────────────────────────────────────────────────────

void UiTopBar::drawTitle(const char* title) {
    auto& g = _tft->gfx();

    // очистим центральную область, чтобы перерисовывать корректно
    g.fillRect(30, 0, UI_W - 60, UI_BAR_H - 1, COL_BAR);

    // шрифт
    g.setTextSize(1);
    g.setTextColor(COL_TEXT);

    // вычисляем ширину текста (моноширинный 6px на символ при size=1)
    uint16_t w = strlen(title) * 6;

    int16_t x = (UI_W / 2) - (w / 2);
    int16_t y = 3;

    g.setCursor(x, y);
    g.print(title);
}

// ─────────────────────────────────────────────────────────────
// ИКОНКИ (ЛЕВО / ПРАВО)
// ─────────────────────────────────────────────────────────────

void UiTopBar::drawIcons(bool wifi, bool mqtt, bool heater, bool uv) {
    auto& g = _tft->gfx();

    // СЛЕВА — Wi-Fi и MQTT
    // Wi-Fi: (x=4, y=3)
    // MQTT:  (x=20, y=4)

    // Wi-Fi ON = зелёные волны → используем ваш специальный цвет COL_WIFI
    // MQTT ON  = фиолетовая точка → COL_MQTT
    // OFF = серый COL_LINE

    // рисуем через драйверские helper’ы
    _tft->drawWifiIcon(4 + 8, 3, wifi);     // иконка ~12px шириной
    _tft->drawDotIcon (20, 4, mqtt);

    // ПРАВАЯ СТОРОНА — HEAT / UV
    // Heat: оранжевый COL_ACCENT
    // UV:   COL_UV

    // x-позиции справа:
    int16_t xUV   = UI_W - 10;
    int16_t xHeat = UI_W - 22;

    // Задний фон подчистим заранее
    g.fillRect(xHeat - 3, 2, 8, 10, COL_BAR);
    g.fillRect(xUV   - 3, 2, 8, 10, COL_BAR);

    // Heat
    if (heater)
        g.fillCircle(xHeat, 5, 2, COL_ACCENT);
    else
        g.drawCircle(xHeat, 5, 2, COL_LINE);

    // UV
    if (uv)
        g.fillCircle(xUV, 5, 2, COL_UV);
    else
        g.drawCircle(xUV, 5, 2, COL_LINE);
}
