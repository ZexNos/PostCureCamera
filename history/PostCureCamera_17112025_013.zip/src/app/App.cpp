#include "app/App.h"

namespace {
    constexpr uint32_t TOPBAR_UPDATE_MS = 250;
}

void App::begin()
{
    // --- init HW ---
    tft.begin();
    tft.setInverted(false);

    enc.begin();
    ui.begin(&tft);

    // --- init top bar ---
    topBar.begin(&tft);
    topBar.drawStatic("RUN");   // название текущего экрана

    // --- init Run View ---
    runView.begin(&tft);
    runSelected = 0;
    runView.drawStatic();
    runView.setSelected(runSelected);

    lastTopbarUpdate = millis();

#if HAS_WIFI
    wifi.begin();
#endif

#if HAS_MQTT
    mqtt.begin();
#endif
}

void App::tick()
{
    enc.tick();

#if HAS_WIFI
    wifi.tick();
#endif

#if HAS_MQTT
    mqtt.tick();
#endif

    // --- RUN VIEW навигация ---
    bool changed = false;

    if (enc.left()) {
        if (runSelected > 0) {
            runSelected--;
            changed = true;
        }
    }

    if (enc.right()) {
        if (runSelected < 2) {
            runSelected++;
            changed = true;
        }
    }

    if (changed) {
        runView.setSelected(runSelected);
    }

    if (enc.click()) {
        // переходы будут позже
    }

    // --- TopBar periodic update ---
    uint32_t now = millis();
    if (now - lastTopbarUpdate >= TOPBAR_UPDATE_MS) {

        bool wifiOK   = false;
        bool mqttOK   = false;
        bool heaterOn = false;
        bool uvOn     = false;

#if HAS_WIFI
        wifiOK = wifi.connected();
#endif
#if HAS_MQTT
        mqttOK = mqtt.connected();
#endif

        topBar.update(wifiOK, mqttOK, heaterOn, uvOn);
        lastTopbarUpdate = now;
    }
}
