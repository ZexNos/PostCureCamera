HOME
├─ CURE
│  └─ CURE PRESETS
│     ├─ Resin A (Std)
│     ├─ Resin B (Fast)
│     ├─ Clear Gentle
│     ├─ Tough 45°C
│     ├─ Dental Model
│     ├─ ABS-like 50°C
│     ├─ Add new...
│     └─ Back
│        └─ RUN VIEW
│           ├─ OPTIONS
│           │  ├─ Pause / Resume
│           │  ├─ Adjust
│           │  │  ├─ UV +10%
│           │  │  ├─ UV −10%
│           │  │  ├─ Heat +5°C
│           │  │  ├─ Heat −5°C
│           │  │  ├─ Extend +5m
│           │  │  └─ Back
│           │  ├─ Back to Progress
│           │  ├─ Stop
│           │  │  └─ RUN REPORT
│           │  └─ Back
│           └─ (прогресс/индикаторы)
├─ DRY
│  └─ DRY PRESETS
│     ├─ PLA 45°C / 4h
│     ├─ PETG 65°C / 6h
│     ├─ ABS 80°C / 6h
│     ├─ NYLON 90°C / 8h
│     ├─ TPU 50°C / 4h
│     ├─ Custom...
│     ├─ Add new...
│     └─ Back
│        └─ RUN VIEW
│           ├─ OPTIONS (см. ветку выше)
│           └─ (прогресс/индикаторы)
└─ SETUP
   └─ SYSTEM SETTINGS
      ├─ OTA Update
      │  ├─ Check for update
      │  ├─ Download vX.Y.Z
      │  ├─ Install
      │  └─ Back
      ├─ Time Zone
      │  ├─ UTC−2 … UTC+3
      │  └─ Back
      ├─ Factory Reset
      │  ├─ Factory Reset (hold OK 3s)
      │  └─ Back
      ├─ Developer Tools
      │  ├─ Test UV/Heater/Fans
      │  │  ├─ UV On/Off
      │  │  ├─ Heat +5°C
      │  │  ├─ Heat −5°C
      │  │  ├─ Fans In 30%
      │  │  ├─ Fans Out 10%
      │  │  └─ Back
      │  ├─ Sensor Monitor
      │  │  ├─ T_air  … °C
      │  │  ├─ T_heater … °C
      │  │  ├─ RH … %
      │  │  └─ Back
      │  ├─ MQTT Publish Test
      │  │  ├─ Topic: …
      │  │  ├─ Payload: …
      │  │  ├─ Publish
      │  │  └─ Back
      │  ├─ OTA Local Server
      │  │  ├─ Local Server IP …
      │  │  ├─ Start Update
      │  │  └─ Back
      │  ├─ System Info
      │  │  ├─ FW Version v0.4.9e
      │  │  ├─ Uptime …
      │  │  ├─ Free Heap …
      │  │  └─ Back
      │  └─ About
      │     ├─ PostCure Camera UI Demo
      │     ├─ MQTT + OTA ready
      │     └─ Back
      └─ Back

